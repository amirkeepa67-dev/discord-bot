import { pgTable, serial, text, numeric, timestamp } from "drizzle-orm/pg-core";

export const itemsTable = pgTable("items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull().default("0"),
  description: text("description").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Item = typeof itemsTable.$inferSelect;
export type InsertItem = typeof itemsTable.$inferInsert;
