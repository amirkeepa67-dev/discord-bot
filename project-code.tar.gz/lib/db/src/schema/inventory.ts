import { pgTable, serial, text, integer, timestamp, unique } from "drizzle-orm/pg-core";
import { itemsTable } from "./items";

export const inventoryTable = pgTable(
  "inventory",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    itemId: integer("item_id")
      .notNull()
      .references(() => itemsTable.id, { onDelete: "cascade" }),
    quantity: integer("quantity").notNull().default(0),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [unique().on(t.userId, t.itemId)],
);

export type InventoryEntry = typeof inventoryTable.$inferSelect;
