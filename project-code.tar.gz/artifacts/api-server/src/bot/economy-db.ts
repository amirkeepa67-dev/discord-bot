import { pool } from "@workspace/db";
import type { Client, TextChannel } from "discord.js";

export interface ServerConfig {
  guild_id: string;
  currency_symbol: string;
  start_balance: string;
  max_cash: string | null;
  max_bank: string | null;
  audit_log_channel: string | null;
}

export interface Wallet {
  id: number;
  guild_id: string;
  user_id: string;
  cash: string;
  bank: string;
}

export async function getConfig(guildId: string): Promise<ServerConfig> {
  await pool.query(
    `INSERT INTO server_config (guild_id) VALUES ($1) ON CONFLICT (guild_id) DO NOTHING`,
    [guildId],
  );
  const res = await pool.query<ServerConfig>(
    `SELECT * FROM server_config WHERE guild_id = $1`,
    [guildId],
  );
  return res.rows[0]!;
}

export async function updateConfig(
  guildId: string,
  field: string,
  value: string | null,
): Promise<void> {
  const allowed = [
    "currency_symbol",
    "start_balance",
    "max_cash",
    "max_bank",
    "audit_log_channel",
  ];
  if (!allowed.includes(field)) throw new Error("Invalid config field");
  await pool.query(`UPDATE server_config SET ${field} = $1 WHERE guild_id = $2`, [
    value,
    guildId,
  ]);
}

export async function getOrCreateWallet(
  guildId: string,
  userId: string,
): Promise<Wallet> {
  const config = await getConfig(guildId);
  await pool.query(
    `INSERT INTO wallets (guild_id, user_id, cash, bank)
     VALUES ($1, $2, $3, 0)
     ON CONFLICT (guild_id, user_id) DO NOTHING`,
    [guildId, userId, config.start_balance],
  );
  const res = await pool.query<Wallet>(
    `SELECT * FROM wallets WHERE guild_id = $1 AND user_id = $2`,
    [guildId, userId],
  );
  return res.rows[0]!;
}

export async function addMoney(
  guildId: string,
  userId: string,
  type: "cash" | "bank",
  amount: number,
): Promise<Wallet> {
  const config = await getConfig(guildId);
  let cap = "";
  if (type === "cash" && config.max_cash) {
    cap = `, cash = LEAST(wallets.cash + $3, ${parseFloat(config.max_cash)})`;
  } else if (type === "bank" && config.max_bank) {
    cap = `, bank = LEAST(wallets.bank + $3, ${parseFloat(config.max_bank)})`;
  }
  await pool.query(
    `UPDATE wallets SET ${type} = ${type} + $3 ${cap} WHERE guild_id = $1 AND user_id = $2`,
    [guildId, userId, amount],
  );
  return getOrCreateWallet(guildId, userId);
}

export async function removeMoney(
  guildId: string,
  userId: string,
  type: "cash" | "bank",
  amount: number,
): Promise<{ success: boolean; wallet: Wallet }> {
  const wallet = await getOrCreateWallet(guildId, userId);
  const current = parseFloat(wallet[type]);
  if (current < amount) return { success: false, wallet };
  await pool.query(
    `UPDATE wallets SET ${type} = ${type} - $3 WHERE guild_id = $1 AND user_id = $2`,
    [guildId, userId, amount],
  );
  const updated = await getOrCreateWallet(guildId, userId);
  return { success: true, wallet: updated };
}

export async function transferCash(
  guildId: string,
  fromId: string,
  toId: string,
  amount: number,
): Promise<{ success: boolean; reason?: string }> {
  const from = await getOrCreateWallet(guildId, fromId);
  if (parseFloat(from.cash) < amount)
    return { success: false, reason: "Insufficient cash" };
  const config = await getConfig(guildId);
  const to = await getOrCreateWallet(guildId, toId);
  if (config.max_cash && parseFloat(to.cash) + amount > parseFloat(config.max_cash))
    return { success: false, reason: "Recipient would exceed maximum cash balance" };

  const client2 = await pool.connect();
  try {
    await client2.query("BEGIN");
    await client2.query(
      `UPDATE wallets SET cash = cash - $3 WHERE guild_id = $1 AND user_id = $2`,
      [guildId, fromId, amount],
    );
    await client2.query(
      `UPDATE wallets SET cash = cash + $3 WHERE guild_id = $1 AND user_id = $2`,
      [guildId, toId, amount],
    );
    await client2.query("COMMIT");
  } catch (e) {
    await client2.query("ROLLBACK");
    throw e;
  } finally {
    client2.release();
  }
  return { success: true };
}

export async function getLeaderboard(
  guildId: string,
  sortBy: "cash" | "bank" | "total",
  limit: number,
  offset: number,
): Promise<Array<{ user_id: string; cash: string; bank: string; total: string }>> {
  const orderClause =
    sortBy === "total" ? "cash::numeric + bank::numeric" : `${sortBy}::numeric`;
  const res = await pool.query(
    `SELECT user_id, cash, bank, (cash::numeric + bank::numeric)::text AS total
     FROM wallets WHERE guild_id = $1
     ORDER BY ${orderClause} DESC
     LIMIT $2 OFFSET $3`,
    [guildId, limit, offset],
  );
  return res.rows;
}

export async function countLeaderboard(guildId: string): Promise<number> {
  const res = await pool.query<{ count: string }>(
    `SELECT COUNT(*) AS count FROM wallets WHERE guild_id = $1`,
    [guildId],
  );
  return parseInt(res.rows[0]?.count ?? "0", 10);
}

export async function resetWallet(
  guildId: string,
  userId: string,
): Promise<void> {
  const config = await getConfig(guildId);
  await pool.query(
    `INSERT INTO wallets (guild_id, user_id, cash, bank)
     VALUES ($1, $2, $3, 0)
     ON CONFLICT (guild_id, user_id)
     DO UPDATE SET cash = $3, bank = 0`,
    [guildId, userId, config.start_balance],
  );
}

export async function logAudit(
  guildId: string,
  userId: string,
  changeType: string,
  amount: number,
  performedBy: string,
  reason?: string,
): Promise<void> {
  await pool.query(
    `INSERT INTO money_audit_log (guild_id, user_id, change_type, amount, performed_by, reason)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [guildId, userId, changeType, amount, performedBy, reason ?? null],
  );
}

export async function sendAuditLog(
  client: Client,
  guildId: string,
  message: string,
): Promise<void> {
  const config = await getConfig(guildId);
  if (!config.audit_log_channel) return;
  const ch = client.channels.cache.get(config.audit_log_channel);
  if (ch?.isTextBased()) {
    await (ch as TextChannel).send(message).catch(() => undefined);
  }
}

export function fmt(config: ServerConfig, amount: number | string): string {
  return `${config.currency_symbol}${parseFloat(String(amount)).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function parseAmount(raw: string, maxVal: number): number | null {
  if (raw.toLowerCase() === "all") return maxVal;
  const n = parseFloat(raw);
  if (isNaN(n) || n <= 0) return null;
  return n;
}
