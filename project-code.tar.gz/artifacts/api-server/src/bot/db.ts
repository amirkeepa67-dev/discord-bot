import { pool } from "@workspace/db";
import type { PoolClient } from "pg";

export interface Item {
  id: number;
  name: string;
  price: string;
  description: string;
  created_at: Date;
}

export interface InventoryRow {
  id: number;
  user_id: string;
  item_id: number;
  quantity: number;
  updated_at: Date;
  name: string;
  price: string;
  description: string;
}

export async function getItemByName(name: string): Promise<Item | null> {
  const res = await pool.query<Item>(
    "SELECT * FROM items WHERE LOWER(name) = LOWER($1)",
    [name],
  );
  return res.rows[0] ?? null;
}

export async function itemNameExists(name: string): Promise<boolean> {
  const res = await pool.query(
    "SELECT 1 FROM items WHERE LOWER(name) = LOWER($1)",
    [name],
  );
  return (res.rowCount ?? 0) > 0;
}

export async function createItem(name: string): Promise<Item> {
  const res = await pool.query<Item>(
    "INSERT INTO items (name) VALUES ($1) RETURNING *",
    [name],
  );
  return res.rows[0]!;
}

export async function updateItemName(
  currentName: string,
  newName: string,
): Promise<Item | null> {
  const res = await pool.query<Item>(
    "UPDATE items SET name = $1 WHERE LOWER(name) = LOWER($2) RETURNING *",
    [newName, currentName],
  );
  return res.rows[0] ?? null;
}

export async function updateItemPrice(
  name: string,
  price: number,
): Promise<Item | null> {
  const res = await pool.query<Item>(
    "UPDATE items SET price = $1 WHERE LOWER(name) = LOWER($2) RETURNING *",
    [price, name],
  );
  return res.rows[0] ?? null;
}

export async function updateItemDescription(
  name: string,
  description: string,
): Promise<Item | null> {
  const res = await pool.query<Item>(
    "UPDATE items SET description = $1 WHERE LOWER(name) = LOWER($2) RETURNING *",
    [description, name],
  );
  return res.rows[0] ?? null;
}

export async function deleteItem(name: string): Promise<boolean> {
  const res = await pool.query(
    "DELETE FROM items WHERE LOWER(name) = LOWER($1)",
    [name],
  );
  return (res.rowCount ?? 0) > 0;
}

export async function getStoreItems(
  limit: number,
  offset: number,
): Promise<Item[]> {
  const res = await pool.query<Item>(
    "SELECT * FROM items ORDER BY name LIMIT $1 OFFSET $2",
    [limit, offset],
  );
  return res.rows;
}

export async function countItems(): Promise<number> {
  const res = await pool.query<{ count: string }>(
    "SELECT COUNT(*) AS count FROM items",
  );
  return parseInt(res.rows[0]?.count ?? "0", 10);
}

export async function searchItems(query: string, limit = 25): Promise<Item[]> {
  const res = await pool.query<Item>(
    "SELECT * FROM items WHERE LOWER(name) LIKE LOWER($1) ORDER BY name LIMIT $2",
    [`%${query}%`, limit],
  );
  return res.rows;
}

export async function getUserInventory(
  userId: string,
  limit: number,
  offset: number,
): Promise<InventoryRow[]> {
  const res = await pool.query<InventoryRow>(
    `SELECT inv.*, items.name, items.price, items.description
     FROM inventory inv
     JOIN items ON inv.item_id = items.id
     WHERE inv.user_id = $1 AND inv.quantity > 0
     ORDER BY items.name
     LIMIT $2 OFFSET $3`,
    [userId, limit, offset],
  );
  return res.rows;
}

export async function countUserInventory(userId: string): Promise<number> {
  const res = await pool.query<{ count: string }>(
    "SELECT COUNT(*) AS count FROM inventory WHERE user_id = $1 AND quantity > 0",
    [userId],
  );
  return parseInt(res.rows[0]?.count ?? "0", 10);
}

export async function getUserItemEntry(
  userId: string,
  itemId: number,
): Promise<{ quantity: number } | null> {
  const res = await pool.query<{ quantity: number }>(
    "SELECT quantity FROM inventory WHERE user_id = $1 AND item_id = $2",
    [userId, itemId],
  );
  return res.rows[0] ?? null;
}

export async function addToInventory(
  userId: string,
  itemId: number,
  quantity: number,
): Promise<void> {
  await pool.query(
    `INSERT INTO inventory (user_id, item_id, quantity, updated_at)
     VALUES ($1, $2, $3, NOW())
     ON CONFLICT (user_id, item_id)
     DO UPDATE SET quantity = inventory.quantity + $3, updated_at = NOW()`,
    [userId, itemId, quantity],
  );
}

export async function removeFromInventory(
  userId: string,
  itemId: number,
  quantity: number,
): Promise<void> {
  await pool.query(
    `UPDATE inventory SET quantity = quantity - $1, updated_at = NOW()
     WHERE user_id = $2 AND item_id = $3`,
    [quantity, userId, itemId],
  );
  await pool.query(
    "DELETE FROM inventory WHERE user_id = $1 AND item_id = $2 AND quantity <= 0",
    [userId, itemId],
  );
}

export async function transferItem(
  fromUserId: string,
  toUserId: string,
  itemId: number,
  quantity: number,
): Promise<void> {
  const client: PoolClient = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(
      `UPDATE inventory SET quantity = quantity - $1, updated_at = NOW()
       WHERE user_id = $2 AND item_id = $3`,
      [quantity, fromUserId, itemId],
    );
    await client.query(
      "DELETE FROM inventory WHERE user_id = $1 AND item_id = $2 AND quantity <= 0",
      [fromUserId, itemId],
    );
    await client.query(
      `INSERT INTO inventory (user_id, item_id, quantity, updated_at)
       VALUES ($1, $2, $3, NOW())
       ON CONFLICT (user_id, item_id)
       DO UPDATE SET quantity = inventory.quantity + $3, updated_at = NOW()`,
      [toUserId, itemId, quantity],
    );
    await client.query("COMMIT");
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}
