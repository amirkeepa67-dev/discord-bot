import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  GuildMember,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  type ChatInputCommandInteraction,
  type AutocompleteInteraction,
  type StringSelectMenuInteraction,
} from "discord.js";
import {
  getItemByName,
  itemNameExists,
  createItem,
  updateItemName,
  updateItemPrice,
  updateItemDescription,
  deleteItem,
  getStoreItems,
  countItems,
  searchItems,
  getUserInventory,
  countUserInventory,
  getUserItemEntry,
  addToInventory,
  removeFromInventory,
  transferItem,
} from "./db.js";
import { getOrCreateWallet, removeMoney, getConfig, fmt } from "./economy-db.js";

const ITEMS_PER_PAGE = 5;
const INV_PER_PAGE = 10;

function isAdmin(interaction: ChatInputCommandInteraction): boolean {
  const member = interaction.member;
  if (!member) return false;
  if (member instanceof GuildMember) {
    if (member.permissions.has(PermissionFlagsBits.ManageGuild)) return true;
    if (member.roles.cache.some((r) => r.name.toLowerCase() === "bot commander")) return true;
  } else {
    const perms = BigInt(member.permissions as string);
    if ((perms & PermissionFlagsBits.ManageGuild) === PermissionFlagsBits.ManageGuild) return true;
  }
  return false;
}

function noPermissionReply(interaction: ChatInputCommandInteraction) {
  return interaction.reply({
    content: "You need the **Manage Server** permission or the **Bot Commander** role.",
    ephemeral: true,
  });
}

export async function handleAutocomplete(interaction: AutocompleteInteraction) {
  const focused = interaction.options.getFocused(true);
  if (focused.name === "item_name") {
    const items = await searchItems(focused.value as string);
    await interaction.respond(items.map((i) => ({ name: i.name, value: i.name })));
  }
}

export async function handleStoreBuy(interaction: StringSelectMenuInteraction) {
  const itemId = parseInt(interaction.values[0]!, 10);
  const guildId = interaction.guildId;
  const userId = interaction.user.id;
  const { pool } = await import("@workspace/db");
  const res = await pool.query("SELECT * FROM items WHERE id=$1", [itemId]);
  const item = res.rows[0];
  if (!item) return interaction.reply({ content: "Item not found.", ephemeral: true });

  const price = parseFloat(item.price);
  if (price > 0 && guildId) {
    const config = await getConfig(guildId);
    const wallet = await getOrCreateWallet(guildId, userId);
    const cash = parseFloat(wallet.cash);
    if (cash < price) {
      return interaction.reply({
        content: `You need **${fmt(config, price)}** cash to buy **${item.name}** but only have **${fmt(config, cash)}**.`,
        ephemeral: true,
      });
    }
    await removeMoney(guildId, userId, "cash", price);
    await addToInventory(userId, itemId, 1);
    const updated = await getOrCreateWallet(guildId, userId);
    return interaction.reply({
      embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Purchase Successful")
        .setDescription(`You bought **1x ${item.name}** for **${fmt(config, price)}**!`)
        .addFields({ name: "Remaining Cash", value: fmt(config, updated.cash), inline: true })],
      ephemeral: true,
    });
  }

  await addToInventory(userId, itemId, 1);
  return interaction.reply({
    embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Item Added").setDescription(`**1x ${item.name}** added to your inventory.`)],
    ephemeral: true,
  });
}

export async function handleInvUse(interaction: StringSelectMenuInteraction) {
  const itemId = parseInt(interaction.values[0]!, 10);
  const entry = await getUserItemEntry(interaction.user.id, itemId);
  if (!entry || entry.quantity < 1) {
    return interaction.reply({ content: "You don't have that item.", ephemeral: true });
  }
  const { pool } = await import("@workspace/db");
  const res = await pool.query("SELECT * FROM items WHERE id=$1", [itemId]);
  const item = res.rows[0];
  if (!item) return interaction.reply({ content: "Item not found.", ephemeral: true });
  await removeFromInventory(interaction.user.id, itemId, 1);
  return interaction.reply({
    embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle("Item Used").setDescription(`**${interaction.user.displayName}** used **1x ${item.name}**.`)],
  });
}

export const commands = [
  {
    data: new SlashCommandBuilder()
      .setName("create-item")
      .setDescription("Create a new item in the store")
      .addStringOption((opt) => opt.setName("name").setDescription("Item name").setRequired(true)),
    async execute(interaction: ChatInputCommandInteraction) {
      if (!isAdmin(interaction)) return noPermissionReply(interaction);
      const name = interaction.options.getString("name", true).trim();
      if (await itemNameExists(name)) return interaction.reply({ content: `An item named **${name}** already exists.`, ephemeral: true });
      const item = await createItem(name);
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Item Created")
          .addFields({ name: "Name", value: item.name, inline: true }, { name: "Price", value: `${item.price}`, inline: true }, { name: "Description", value: item.description || "None", inline: true })
          .setFooter({ text: "Use /edit-item to set a price or description." })],
      });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName("edit-item")
      .setDescription("Edit an existing item")
      .addStringOption((opt) =>
        opt.setName("option").setDescription("What to edit").setRequired(true)
          .addChoices({ name: "Name", value: "name" }, { name: "Price", value: "price" }, { name: "Description", value: "description" }),
      )
      .addStringOption((opt) => opt.setName("item_name").setDescription("Item to edit").setRequired(true).setAutocomplete(true))
      .addStringOption((opt) => opt.setName("new_value").setDescription("New value").setRequired(true)),
    async execute(interaction: ChatInputCommandInteraction) {
      if (!isAdmin(interaction)) return noPermissionReply(interaction);
      const option = interaction.options.getString("option", true);
      const itemName = interaction.options.getString("item_name", true).trim();
      const newValue = interaction.options.getString("new_value", true).trim();
      const item = await getItemByName(itemName);
      if (!item) return interaction.reply({ content: `Item **${itemName}** not found.`, ephemeral: true });
      let updated; let fieldLabel: string; let fieldValue: string;
      if (option === "name") {
        if (await itemNameExists(newValue)) return interaction.reply({ content: `An item named **${newValue}** already exists.`, ephemeral: true });
        updated = await updateItemName(itemName, newValue); fieldLabel = "Name"; fieldValue = newValue;
      } else if (option === "price") {
        const price = parseFloat(newValue);
        if (isNaN(price) || price < 0) return interaction.reply({ content: "Price must be a valid non-negative number.", ephemeral: true });
        updated = await updateItemPrice(itemName, price); fieldLabel = "Price"; fieldValue = `${price}`;
      } else {
        updated = await updateItemDescription(itemName, newValue); fieldLabel = "Description"; fieldValue = newValue;
      }
      if (!updated) return interaction.reply({ content: `Failed to update **${itemName}**.`, ephemeral: true });
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle("Item Updated").setDescription(`**${item.name}** updated.`).addFields({ name: fieldLabel, value: fieldValue })] });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName("delete-item")
      .setDescription("Delete an item from the store")
      .addStringOption((opt) => opt.setName("item_name").setDescription("Item to delete").setRequired(true).setAutocomplete(true)),
    async execute(interaction: ChatInputCommandInteraction) {
      if (!isAdmin(interaction)) return noPermissionReply(interaction);
      const itemName = interaction.options.getString("item_name", true).trim();
      const deleted = await deleteItem(itemName);
      if (!deleted) return interaction.reply({ content: `Item **${itemName}** not found.`, ephemeral: true });
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setTitle("Item Deleted").setDescription(`**${itemName}** has been removed.`)] });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName("store")
      .setDescription("Browse all available items")
      .addIntegerOption((opt) => opt.setName("page").setDescription("Page number").setMinValue(1)),
    async execute(interaction: ChatInputCommandInteraction) {
      const page = Math.max(1, interaction.options.getInteger("page") ?? 1);
      const total = await countItems();
      const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
      const currentPage = Math.min(page, totalPages);
      const items = await getStoreItems(ITEMS_PER_PAGE, (currentPage - 1) * ITEMS_PER_PAGE);
      if (!items.length) return interaction.reply({ content: "The store is currently empty.", ephemeral: true });

      const guildId = interaction.guildId;
      let config: Awaited<ReturnType<typeof getConfig>> | null = null;
      if (guildId) {
        try { config = await getConfig(guildId); } catch { config = null; }
      }

      const embed = new EmbedBuilder().setColor(0xfee75c).setTitle("🏪 Item Store")
        .setFooter({ text: `Page ${currentPage} of ${totalPages} — ${total} total items | Select below to buy` });

      for (const item of items) {
        const priceStr = config ? fmt(config, item.price) : `$${parseFloat(item.price).toFixed(2)}`;
        embed.addFields({ name: `${item.name} — ${priceStr}`, value: item.description || "*No description*" });
      }

      const menu = new StringSelectMenuBuilder()
        .setCustomId("store:buy")
        .setPlaceholder("🛒 Select an item to buy...")
        .addOptions(
          items.map((item) => ({
            label: item.name.substring(0, 100),
            value: String(item.id),
            description: (item.description || "No description").substring(0, 100),
          })),
        );

      const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);
      return interaction.reply({ embeds: [embed], components: [row] });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName("inventory")
      .setDescription("View a member's inventory")
      .addUserOption((opt) => opt.setName("member").setDescription("Member to check (default: you)"))
      .addIntegerOption((opt) => opt.setName("page").setDescription("Page number").setMinValue(1)),
    async execute(interaction: ChatInputCommandInteraction) {
      const target = interaction.options.getUser("member") ?? interaction.user;
      const page = Math.max(1, interaction.options.getInteger("page") ?? 1);
      const total = await countUserInventory(target.id);
      const totalPages = Math.max(1, Math.ceil(total / INV_PER_PAGE));
      const currentPage = Math.min(page, totalPages);
      const rows = await getUserInventory(target.id, INV_PER_PAGE, (currentPage - 1) * INV_PER_PAGE);
      const isOwn = target.id === interaction.user.id;
      const title = isOwn ? "🎒 Your Inventory" : `🎒 ${target.displayName}'s Inventory`;

      if (!rows.length) {
        return interaction.reply({
          content: isOwn ? "Your inventory is empty. Buy items from `/store`!" : `${target.displayName}'s inventory is empty.`,
          ephemeral: true,
        });
      }

      const guildId = interaction.guildId;
      let config: Awaited<ReturnType<typeof getConfig>> | null = null;
      if (guildId) {
        try { config = await getConfig(guildId); } catch { config = null; }
      }

      const embed = new EmbedBuilder().setColor(0x57f287).setTitle(title).setThumbnail(target.displayAvatarURL())
        .setFooter({ text: `Page ${currentPage} of ${totalPages} — ${total} unique items` });
      for (const row of rows) {
        const priceStr = config ? fmt(config, row.price) : `$${parseFloat(row.price).toFixed(2)}`;
        embed.addFields({ name: `${row.name} × ${row.quantity}`, value: `${priceStr}${row.description ? ` — ${row.description}` : ""}` });
      }

      const components: ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>[] = [];
      if (isOwn && rows.length > 0) {
        const useMenu = new StringSelectMenuBuilder()
          .setCustomId("inv:use")
          .setPlaceholder("🎯 Select an item to use...")
          .addOptions(
            rows.slice(0, 25).map((row) => ({
              label: `${row.name} × ${row.quantity}`,
              value: String(row.item_id),
              description: (row.description || "No description").substring(0, 100),
            })),
          );
        components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(useMenu));
      }

      return interaction.reply({ embeds: [embed], components, ephemeral: isOwn });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName("item-info")
      .setDescription("Get detailed info about an item")
      .addStringOption((opt) => opt.setName("item_name").setDescription("Item name").setRequired(true).setAutocomplete(true)),
    async execute(interaction: ChatInputCommandInteraction) {
      const itemName = interaction.options.getString("item_name", true).trim();
      const item = await getItemByName(itemName);
      if (!item) return interaction.reply({ content: `Item **${itemName}** not found.`, ephemeral: true });
      const guildId = interaction.guildId;
      let priceStr = `$${parseFloat(item.price).toFixed(2)}`;
      if (guildId) { try { const config = await getConfig(guildId); priceStr = fmt(config, item.price); } catch { } }
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle(item.name)
          .addFields({ name: "Price", value: priceStr, inline: true }, { name: "Description", value: item.description || "*No description*", inline: false })
          .setFooter({ text: `Item ID: ${item.id}` })],
      });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName("buy-item")
      .setDescription("Buy an item from the store")
      .addStringOption((opt) => opt.setName("item_name").setDescription("Item to buy").setRequired(true).setAutocomplete(true))
      .addIntegerOption((opt) => opt.setName("quantity").setDescription("Quantity to buy (default: 1)").setMinValue(1)),
    async execute(interaction: ChatInputCommandInteraction) {
      const itemName = interaction.options.getString("item_name", true).trim();
      const quantity = interaction.options.getInteger("quantity") ?? 1;
      const item = await getItemByName(itemName);
      if (!item) return interaction.reply({ content: `Item **${itemName}** not found. Check the store with \`/store\`.`, ephemeral: true });

      const price = parseFloat(item.price);
      const guildId = interaction.guildId;

      if (price > 0 && guildId) {
        const config = await getConfig(guildId);
        const totalCost = price * quantity;
        const wallet = await getOrCreateWallet(guildId, interaction.user.id);
        if (parseFloat(wallet.cash) < totalCost) {
          return interaction.reply({
            content: `You need **${fmt(config, totalCost)}** cash to buy **${quantity}x ${item.name}** but only have **${fmt(config, wallet.cash)}**.`,
            ephemeral: true,
          });
        }
        await removeMoney(guildId, interaction.user.id, "cash", totalCost);
        await addToInventory(interaction.user.id, item.id, quantity);
        const updated = await getOrCreateWallet(guildId, interaction.user.id);
        return interaction.reply({
          embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Purchase Successful")
            .setDescription(`You bought **${quantity}x ${item.name}** for **${fmt(config, totalCost)}**!`)
            .addFields({ name: "Remaining Cash", value: fmt(config, updated.cash), inline: true })],
          ephemeral: true,
        });
      }

      await addToInventory(interaction.user.id, item.id, quantity);
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Purchase Successful").setDescription(`You acquired **${quantity}x ${item.name}**!`)],
        ephemeral: true,
      });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName("sell-item")
      .setDescription("Sell an item to another member")
      .addUserOption((opt) => opt.setName("member").setDescription("Member to sell to").setRequired(true))
      .addStringOption((opt) => opt.setName("item_name").setDescription("Item to sell").setRequired(true).setAutocomplete(true))
      .addNumberOption((opt) => opt.setName("price").setDescription("Price you're selling for").setRequired(true).setMinValue(0))
      .addIntegerOption((opt) => opt.setName("quantity").setDescription("Quantity to sell (default: 1)").setMinValue(1)),
    async execute(interaction: ChatInputCommandInteraction) {
      const buyer = interaction.options.getUser("member", true);
      const itemName = interaction.options.getString("item_name", true).trim();
      const price = interaction.options.getNumber("price", true);
      const quantity = interaction.options.getInteger("quantity") ?? 1;
      if (buyer.id === interaction.user.id) return interaction.reply({ content: "You cannot sell items to yourself.", ephemeral: true });
      if (buyer.bot) return interaction.reply({ content: "You cannot sell items to bots.", ephemeral: true });
      const item = await getItemByName(itemName);
      if (!item) return interaction.reply({ content: `Item **${itemName}** not found.`, ephemeral: true });
      const entry = await getUserItemEntry(interaction.user.id, item.id);
      if (!entry || entry.quantity < quantity)
        return interaction.reply({ content: `You don't have enough **${item.name}** (you have ${entry?.quantity ?? 0}).`, ephemeral: true });

      let priceStr = `$${price.toFixed(2)}`;
      const guildId = interaction.guildId;
      if (price > 0 && guildId) {
        const config = await getConfig(guildId);
        priceStr = fmt(config, price);
        const buyerWallet = await getOrCreateWallet(guildId, buyer.id);
        if (parseFloat(buyerWallet.cash) < price)
          return interaction.reply({ content: `${buyer.displayName} doesn't have enough cash (needs ${fmt(config, price)}).`, ephemeral: true });
        await removeMoney(guildId, buyer.id, "cash", price);
        await addToInventory(interaction.user.id, item.id, 0); // ensure seller wallet exists
        const { addMoney } = await import("./economy-db.js");
        await addMoney(guildId, interaction.user.id, "cash", price);
      }

      await transferItem(interaction.user.id, buyer.id, item.id, quantity);
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(0xfee75c).setTitle("Item Sold")
          .setDescription(`**${interaction.user.displayName}** sold **${quantity}x ${item.name}** to **${buyer.displayName}** for ${priceStr}.`)],
      });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName("use-item")
      .setDescription("Use an item from your inventory")
      .addStringOption((opt) => opt.setName("item_name").setDescription("Item to use").setRequired(true).setAutocomplete(true))
      .addIntegerOption((opt) => opt.setName("quantity").setDescription("Quantity to use (default: 1)").setMinValue(1)),
    async execute(interaction: ChatInputCommandInteraction) {
      const itemName = interaction.options.getString("item_name", true).trim();
      const quantity = interaction.options.getInteger("quantity") ?? 1;
      const item = await getItemByName(itemName);
      if (!item) return interaction.reply({ content: `Item **${itemName}** not found.`, ephemeral: true });
      const entry = await getUserItemEntry(interaction.user.id, item.id);
      if (!entry || entry.quantity < quantity)
        return interaction.reply({ content: `You don't have enough **${item.name}** (you have ${entry?.quantity ?? 0}).`, ephemeral: true });
      await removeFromInventory(interaction.user.id, item.id, quantity);
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle("Item Used").setDescription(`**${interaction.user.displayName}** used **${quantity}x ${item.name}**.`)],
      });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName("give-item")
      .setDescription("Give an item to a member")
      .addUserOption((opt) => opt.setName("member").setDescription("Member to give item to").setRequired(true))
      .addStringOption((opt) => opt.setName("item_name").setDescription("Item to give").setRequired(true).setAutocomplete(true))
      .addIntegerOption((opt) => opt.setName("quantity").setDescription("Quantity to give (default: 1)").setMinValue(1)),
    async execute(interaction: ChatInputCommandInteraction) {
      if (!isAdmin(interaction)) return noPermissionReply(interaction);
      const target = interaction.options.getUser("member", true);
      const itemName = interaction.options.getString("item_name", true).trim();
      const quantity = interaction.options.getInteger("quantity") ?? 1;
      if (target.bot) return interaction.reply({ content: "You cannot give items to bots.", ephemeral: true });
      const item = await getItemByName(itemName);
      if (!item) return interaction.reply({ content: `Item **${itemName}** not found.`, ephemeral: true });
      await addToInventory(target.id, item.id, quantity);
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Item Given").setDescription(`**${quantity}x ${item.name}** given to **${target.displayName}**.`)] });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName("take-item")
      .setDescription("Take an item from a member")
      .addUserOption((opt) => opt.setName("member").setDescription("Member to take item from").setRequired(true))
      .addStringOption((opt) => opt.setName("item_name").setDescription("Item to take").setRequired(true).setAutocomplete(true))
      .addIntegerOption((opt) => opt.setName("quantity").setDescription("Quantity to take (default: 1)").setMinValue(1)),
    async execute(interaction: ChatInputCommandInteraction) {
      if (!isAdmin(interaction)) return noPermissionReply(interaction);
      const target = interaction.options.getUser("member", true);
      const itemName = interaction.options.getString("item_name", true).trim();
      const quantity = interaction.options.getInteger("quantity") ?? 1;
      const item = await getItemByName(itemName);
      if (!item) return interaction.reply({ content: `Item **${itemName}** not found.`, ephemeral: true });
      const entry = await getUserItemEntry(target.id, item.id);
      if (!entry || entry.quantity < quantity)
        return interaction.reply({ content: `**${target.displayName}** doesn't have enough **${item.name}** (they have ${entry?.quantity ?? 0}).`, ephemeral: true });
      await removeFromInventory(target.id, item.id, quantity);
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setTitle("Item Taken").setDescription(`**${quantity}x ${item.name}** removed from **${target.displayName}**'s inventory.`)] });
    },
  },
];
