import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  type ChatInputCommandInteraction,
  type ButtonInteraction,
} from "discord.js";
import {
  getOrCreateWallet,
  addMoney,
  removeMoney,
  getConfig,
  fmt,
} from "../economy-db.js";

interface BJGame {
  deck: number[];
  player: number[];
  dealer: number[];
  bet: number;
  guildId: string;
  userId: string;
}

export const bjGames = new Map<string, BJGame>();

const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

function freshDeck(): number[] {
  const deck: number[] = [];
  for (let i = 0; i < 52; i++) deck.push(i);
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j]!, deck[i]!];
  }
  return deck;
}

function cardName(c: number): string {
  return `${RANKS[c % 13]!}${SUITS[Math.floor(c / 13)]!}`;
}

function handValue(cards: number[]): number {
  let total = 0;
  let aces = 0;
  for (const c of cards) {
    const rank = c % 13;
    if (rank === 0) { total += 11; aces++; }
    else if (rank >= 10) total += 10;
    else total += rank + 1;
  }
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
}

function bjEmbed(game: BJGame, config: ReturnType<typeof fmt> extends string ? any : any, reveal = false): EmbedBuilder {
  const pVal = handValue(game.player);
  const dCards = reveal ? game.dealer.map(cardName).join(" ") : `${cardName(game.dealer[0]!)} ?`;
  const dVal = reveal ? handValue(game.dealer) : "?";
  return new EmbedBuilder()
    .setColor(0x57f287)
    .setTitle("Blackjack")
    .addFields(
      { name: `Your Hand (${pVal})`, value: game.player.map(cardName).join(" "), inline: true },
      { name: `Dealer Hand (${dVal})`, value: dCards, inline: true },
      { name: "Bet", value: fmt(config, game.bet), inline: false },
    );
}

function bjRow(gameKey: string) {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`bj:hit:${gameKey}`).setLabel("Hit").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`bj:stand:${gameKey}`).setLabel("Stand").setStyle(ButtonStyle.Danger),
  );
}

export async function handleBjButton(i: ButtonInteraction, action: string, gameKey: string) {
  const game = bjGames.get(gameKey);
  if (!game || game.userId !== i.user.id) {
    return i.reply({ content: "This isn't your game.", ephemeral: true });
  }
  const config = await getConfig(game.guildId);

  if (action === "hit") {
    const card = game.deck.pop()!;
    game.player.push(card);
    const val = handValue(game.player);
    if (val > 21) {
      bjGames.delete(gameKey);
      const embed = bjEmbed(game, config, true).setColor(0xed4245).setDescription(`Bust! You drew ${cardName(card)} and went over 21. You lose **${fmt(config, game.bet)}**.`);
      return i.update({ embeds: [embed], components: [] });
    }
    if (val === 21) {
      return handleBjStand(i, game, config, gameKey);
    }
    return i.update({ embeds: [bjEmbed(game, config)], components: [bjRow(gameKey)] });
  }
  return handleBjStand(i, game, config, gameKey);
}

async function handleBjStand(i: ButtonInteraction, game: BJGame, config: any, gameKey: string) {
  while (handValue(game.dealer) < 17) {
    game.dealer.push(game.deck.pop()!);
  }
  const pVal = handValue(game.player);
  const dVal = handValue(game.dealer);
  bjGames.delete(gameKey);
  let result: string;
  let color: number;
  if (dVal > 21 || pVal > dVal) {
    await addMoney(game.guildId, game.userId, "cash", game.bet);
    result = `You win **${fmt(config, game.bet)}**! Your ${pVal} beats dealer's ${dVal}.`;
    color = 0x57f287;
  } else if (pVal === dVal) {
    await addMoney(game.guildId, game.userId, "cash", game.bet);
    result = `Push! Both at ${pVal}. Bet returned.`;
    color = 0xfee75c;
  } else {
    result = `Dealer wins. Your ${pVal} loses to dealer's ${dVal}. You lose **${fmt(config, game.bet)}**.`;
    color = 0xed4245;
  }
  const embed = bjEmbed(game, config, true).setColor(color).setDescription(result);
  return i.update({ embeds: [embed], components: [] });
}

const SLOT_SYMBOLS = ["🍒", "🍋", "🍇", "⭐", "💎", "🃏"];
const SLOT_MULT: Record<string, number> = { "💎": 50, "⭐": 15, "🍇": 8, "🍋": 5, "🍒": 3, "🃏": 2 };

export const casinoCommands = [
  {
    data: new SlashCommandBuilder()
      .setName("slots")
      .setDescription("Play the slot machine")
      .addNumberOption((o) => o.setName("bet").setDescription("Amount to bet").setRequired(true).setMinValue(1)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const bet = i.options.getNumber("bet", true);
      const wallet = await getOrCreateWallet(i.guildId, i.user.id);
      if (parseFloat(wallet.cash) < bet) return i.reply({ content: "Insufficient cash.", ephemeral: true });
      const config = await getConfig(i.guildId);
      const { success } = await removeMoney(i.guildId, i.user.id, "cash", bet);
      if (!success) return i.reply({ content: "Insufficient cash.", ephemeral: true });

      const reels = [
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)]!,
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)]!,
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)]!,
      ];

      let winnings = 0;
      let resultMsg = "";
      if (reels[0] === reels[1] && reels[1] === reels[2]) {
        const mult = SLOT_MULT[reels[0]!] ?? 2;
        winnings = bet * mult;
        await addMoney(i.guildId, i.user.id, "cash", winnings);
        resultMsg = `JACKPOT! **${reels[0]}${reels[1]}${reels[2]}** — you win **${fmt(config, winnings)}** (${mult}x)!`;
      } else if (reels[0] === reels[1] || reels[1] === reels[2] || reels[0] === reels[2]) {
        winnings = bet * 1.5;
        await addMoney(i.guildId, i.user.id, "cash", winnings);
        resultMsg = `Two of a kind! **${reels[0]} ${reels[1]} ${reels[2]}** — you win **${fmt(config, winnings)}**!`;
      } else {
        resultMsg = `**${reels[0]} ${reels[1]} ${reels[2]}** — no match. You lose **${fmt(config, bet)}**.`;
      }

      return i.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(winnings > 0 ? 0x57f287 : 0xed4245)
            .setTitle("Slot Machine")
            .setDescription(`╔══════════════╗\n║  ${reels[0]}  ${reels[1]}  ${reels[2]}  ║\n╚══════════════╝\n\n${resultMsg}`),
        ],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("dice")
      .setDescription("Roll dice and bet")
      .addNumberOption((o) => o.setName("bet").setDescription("Amount to bet").setRequired(true).setMinValue(1))
      .addStringOption((o) =>
        o.setName("guess").setDescription("Your guess").setRequired(true)
          .addChoices(
            { name: "High (8-12)", value: "high" },
            { name: "Low (2-6)", value: "low" },
            { name: "Exactly 7", value: "seven" },
          ),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const bet = i.options.getNumber("bet", true);
      const guess = i.options.getString("guess", true);
      const wallet = await getOrCreateWallet(i.guildId, i.user.id);
      if (parseFloat(wallet.cash) < bet) return i.reply({ content: "Insufficient cash.", ephemeral: true });
      const config = await getConfig(i.guildId);
      const { success } = await removeMoney(i.guildId, i.user.id, "cash", bet);
      if (!success) return i.reply({ content: "Insufficient cash.", ephemeral: true });

      const d1 = Math.floor(Math.random() * 6) + 1;
      const d2 = Math.floor(Math.random() * 6) + 1;
      const total = d1 + d2;
      const diceFaces = ["", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣"];
      const won = (guess === "high" && total >= 8) || (guess === "low" && total <= 6) || (guess === "seven" && total === 7);
      const mult = guess === "seven" ? 5 : 2;
      let resultMsg = "";
      if (won) {
        const winnings = bet * mult;
        await addMoney(i.guildId, i.user.id, "cash", winnings);
        resultMsg = `You guessed **${guess}** and rolled **${total}**! Win **${fmt(config, winnings)}**!`;
      } else {
        resultMsg = `You guessed **${guess}** but rolled **${total}**. You lose **${fmt(config, bet)}**.`;
      }

      return i.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(won ? 0x57f287 : 0xed4245)
            .setTitle("Dice Roll")
            .setDescription(`${diceFaces[d1]} ${diceFaces[d2]} — Total: **${total}**\n\n${resultMsg}`),
        ],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("blackjack")
      .setDescription("Play blackjack against the dealer")
      .addNumberOption((o) => o.setName("bet").setDescription("Amount to bet").setRequired(true).setMinValue(1)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const bet = i.options.getNumber("bet", true);
      const wallet = await getOrCreateWallet(i.guildId, i.user.id);
      if (parseFloat(wallet.cash) < bet) return i.reply({ content: "Insufficient cash.", ephemeral: true });
      const config = await getConfig(i.guildId);
      const { success } = await removeMoney(i.guildId, i.user.id, "cash", bet);
      if (!success) return i.reply({ content: "Insufficient cash.", ephemeral: true });

      const deck = freshDeck();
      const player = [deck.pop()!, deck.pop()!];
      const dealer = [deck.pop()!, deck.pop()!];
      const gameKey = `${i.guildId}_${i.user.id}`;

      const game: BJGame = { deck, player, dealer, bet, guildId: i.guildId, userId: i.user.id };

      if (handValue(player) === 21) {
        bjGames.delete(gameKey);
        const winnings = bet * 2.5;
        await addMoney(i.guildId, i.user.id, "cash", winnings);
        const embed = bjEmbed(game, config, true).setColor(0xfee75c).setDescription(`**Blackjack!** You win **${fmt(config, winnings)}**!`);
        return i.reply({ embeds: [embed], components: [] });
      }

      bjGames.set(gameKey, game);
      return i.reply({ embeds: [bjEmbed(game, config)], components: [bjRow(gameKey)] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("coinflip")
      .setDescription("Flip a coin and bet")
      .addNumberOption((o) => o.setName("bet").setDescription("Amount to bet").setRequired(true).setMinValue(1))
      .addStringOption((o) =>
        o.setName("side").setDescription("Heads or Tails").setRequired(true)
          .addChoices({ name: "Heads", value: "heads" }, { name: "Tails", value: "tails" }),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const bet = i.options.getNumber("bet", true);
      const side = i.options.getString("side", true);
      const wallet = await getOrCreateWallet(i.guildId, i.user.id);
      if (parseFloat(wallet.cash) < bet) return i.reply({ content: "Insufficient cash.", ephemeral: true });
      const config = await getConfig(i.guildId);
      const { success } = await removeMoney(i.guildId, i.user.id, "cash", bet);
      if (!success) return i.reply({ content: "Insufficient cash.", ephemeral: true });

      const result = Math.random() < 0.5 ? "heads" : "tails";
      const won = result === side;
      if (won) await addMoney(i.guildId, i.user.id, "cash", bet * 2);

      return i.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(won ? 0x57f287 : 0xed4245)
            .setTitle("Coin Flip")
            .setDescription(`${result === "heads" ? "🪙 **Heads**" : "🔵 **Tails**"}\n\n${won ? `You guessed correctly! Win **${fmt(config, bet)}**!` : `Bad luck — it was **${result}**. You lose **${fmt(config, bet)}**.`}`),
        ],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("roulette")
      .setDescription("Play roulette")
      .addNumberOption((o) => o.setName("bet").setDescription("Amount to bet").setRequired(true).setMinValue(1))
      .addStringOption((o) =>
        o.setName("choice").setDescription("What to bet on").setRequired(true)
          .addChoices(
            { name: "Red", value: "red" },
            { name: "Black", value: "black" },
            { name: "Green (0)", value: "green" },
            { name: "Odd", value: "odd" },
            { name: "Even", value: "even" },
            { name: "1-18", value: "low" },
            { name: "19-36", value: "high" },
          ),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const bet = i.options.getNumber("bet", true);
      const choice = i.options.getString("choice", true);
      const wallet = await getOrCreateWallet(i.guildId, i.user.id);
      if (parseFloat(wallet.cash) < bet) return i.reply({ content: "Insufficient cash.", ephemeral: true });
      const config = await getConfig(i.guildId);
      const { success } = await removeMoney(i.guildId, i.user.id, "cash", bet);
      if (!success) return i.reply({ content: "Insufficient cash.", ephemeral: true });

      const num = Math.floor(Math.random() * 37);
      const redNums = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
      const isRed = redNums.includes(num);
      const color = num === 0 ? "🟢" : isRed ? "🔴" : "⚫";

      let won = false;
      let mult = 2;
      if (choice === "red" && isRed) won = true;
      else if (choice === "black" && num !== 0 && !isRed) won = true;
      else if (choice === "green" && num === 0) { won = true; mult = 14; }
      else if (choice === "odd" && num !== 0 && num % 2 === 1) won = true;
      else if (choice === "even" && num !== 0 && num % 2 === 0) won = true;
      else if (choice === "low" && num >= 1 && num <= 18) won = true;
      else if (choice === "high" && num >= 19 && num <= 36) won = true;

      if (won) await addMoney(i.guildId, i.user.id, "cash", bet * mult);

      return i.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(won ? 0x57f287 : 0xed4245)
            .setTitle("Roulette")
            .setDescription(`The ball lands on ${color} **${num}**!\n\n${won ? `You bet **${choice}** and win **${fmt(config, bet * mult)}**!` : `You bet **${choice}** and lose **${fmt(config, bet)}**.`}`),
        ],
      });
    },
  },
];
