import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  GuildMember,
  ChannelType,
  type ChatInputCommandInteraction,
  type Client,
} from "discord.js";
import { pool } from "@workspace/db";
import {
  getConfig,
  updateConfig,
  getOrCreateWallet,
  addMoney,
  removeMoney,
  transferCash,
  getLeaderboard,
  countLeaderboard,
  resetWallet,
  logAudit,
  sendAuditLog,
  fmt,
  parseAmount,
} from "../economy-db.js";

function isAdmin(interaction: ChatInputCommandInteraction): boolean {
  const m = interaction.member;
  if (!m) return false;
  if (m instanceof GuildMember) {
    if (m.permissions.has(PermissionFlagsBits.ManageGuild)) return true;
    if (m.roles.cache.some((r) => r.name.toLowerCase() === "bot commander")) return true;
  } else {
    const p = BigInt(m.permissions as string);
    if ((p & PermissionFlagsBits.ManageGuild) === PermissionFlagsBits.ManageGuild) return true;
  }
  return false;
}

function noPerm(i: ChatInputCommandInteraction) {
  return i.reply({ content: "You need **Manage Server** or **Bot Commander** for this command.", ephemeral: true });
}

function guildOnly(i: ChatInputCommandInteraction) {
  return i.reply({ content: "This command can only be used in a server.", ephemeral: true });
}

export function makeEconomyCommands(client: Client) {
  return [
    {
      data: new SlashCommandBuilder()
        .setName("set-currency")
        .setDescription("Set the currency symbol for this server")
        .addStringOption((o) =>
          o.setName("symbol").setDescription("Currency symbol (e.g. $ or 💰)").setRequired(true),
        ),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        if (!isAdmin(i)) return noPerm(i);
        const symbol = i.options.getString("symbol", true);
        await updateConfig(i.guildId, "currency_symbol", symbol);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`Currency symbol set to **${symbol}**`)] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("set-start-balance")
        .setDescription("Set the starting balance for new users")
        .addNumberOption((o) =>
          o.setName("amount").setDescription("Starting amount").setRequired(true).setMinValue(0),
        ),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        if (!isAdmin(i)) return noPerm(i);
        const amount = i.options.getNumber("amount", true);
        await updateConfig(i.guildId, "start_balance", String(amount));
        const config = await getConfig(i.guildId);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`Starting balance set to **${fmt(config, amount)}**`)] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("money-audit-log")
        .setDescription("Enable or disable money audit logging")
        .addStringOption((o) =>
          o.setName("action").setDescription("enable or disable").setRequired(true)
            .addChoices({ name: "Enable", value: "enable" }, { name: "Disable", value: "disable" }),
        )
        .addChannelOption((o) =>
          o.setName("channel").setDescription("Channel to log to (required when enabling)")
            .addChannelTypes(ChannelType.GuildText),
        ),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        if (!isAdmin(i)) return noPerm(i);
        const action = i.options.getString("action", true);
        if (action === "disable") {
          await updateConfig(i.guildId, "audit_log_channel", null);
          return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("Money audit log **disabled**.")] });
        }
        const ch = i.options.getChannel("channel");
        if (!ch) return i.reply({ content: "Please specify a channel to log to.", ephemeral: true });
        await updateConfig(i.guildId, "audit_log_channel", ch.id);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`Money audit log enabled in <#${ch.id}>`)] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("maximum-balance")
        .setDescription("Set a maximum balance cap")
        .addStringOption((o) =>
          o.setName("type").setDescription("cash or bank").setRequired(true)
            .addChoices({ name: "Cash", value: "cash" }, { name: "Bank", value: "bank" }),
        )
        .addNumberOption((o) =>
          o.setName("amount").setDescription("Maximum amount (0 to remove cap)").setRequired(true).setMinValue(0),
        ),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        if (!isAdmin(i)) return noPerm(i);
        const type = i.options.getString("type", true) as "cash" | "bank";
        const amount = i.options.getNumber("amount", true);
        const field = type === "cash" ? "max_cash" : "max_bank";
        await updateConfig(i.guildId, field, amount === 0 ? null : String(amount));
        const config = await getConfig(i.guildId);
        const msg = amount === 0
          ? `Maximum ${type} balance cap **removed**.`
          : `Maximum ${type} balance set to **${fmt(config, amount)}**`;
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x5865f2).setDescription(msg)] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("add-money")
        .setDescription("Add money to a member's balance")
        .addUserOption((o) => o.setName("member").setDescription("Member").setRequired(true))
        .addNumberOption((o) => o.setName("amount").setDescription("Amount").setRequired(true).setMinValue(0.01))
        .addStringOption((o) =>
          o.setName("type").setDescription("cash or bank (default: cash)")
            .addChoices({ name: "Cash", value: "cash" }, { name: "Bank", value: "bank" }),
        ),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        if (!isAdmin(i)) return noPerm(i);
        const target = i.options.getUser("member", true);
        const amount = i.options.getNumber("amount", true);
        const type = (i.options.getString("type") ?? "cash") as "cash" | "bank";
        await getOrCreateWallet(i.guildId, target.id);
        const wallet = await addMoney(i.guildId, target.id, type, amount);
        const config = await getConfig(i.guildId);
        await logAudit(i.guildId, target.id, `add_${type}`, amount, i.user.id);
        await sendAuditLog(client, i.guildId, `💰 **${i.user.displayName}** added ${fmt(config, amount)} ${type} to **${target.displayName}** | New balance: ${fmt(config, wallet[type])}`);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Money Added").addFields({ name: "Member", value: `${target}`, inline: true }, { name: type === "cash" ? "Cash" : "Bank", value: fmt(config, wallet[type]), inline: true })] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("add-money-role")
        .setDescription("Add money to all members with a role")
        .addRoleOption((o) => o.setName("role").setDescription("Role").setRequired(true))
        .addNumberOption((o) => o.setName("amount").setDescription("Amount").setRequired(true).setMinValue(0.01))
        .addStringOption((o) =>
          o.setName("type").setDescription("cash or bank (default: cash)")
            .addChoices({ name: "Cash", value: "cash" }, { name: "Bank", value: "bank" }),
        ),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        if (!isAdmin(i)) return noPerm(i);
        if (!i.guild) return guildOnly(i);
        const role = i.options.getRole("role", true);
        const amount = i.options.getNumber("amount", true);
        const type = (i.options.getString("type") ?? "cash") as "cash" | "bank";
        await i.deferReply();
        const members = await i.guild.members.fetch();
        const config = await getConfig(i.guildId);
        let count = 0;
        for (const [, member] of members) {
          if (member.user.bot) continue;
          if (member.roles.cache.has(role.id)) {
            await getOrCreateWallet(i.guildId, member.id);
            await addMoney(i.guildId, member.id, type, amount);
            count++;
          }
        }
        await sendAuditLog(client, i.guildId, `💰 **${i.user.displayName}** added ${fmt(config, amount)} ${type} to **${count}** members with role @${role.name}`);
        return i.editReply({ embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Money Added to Role").setDescription(`Added **${fmt(config, amount)}** ${type} to **${count}** members with <@&${role.id}>`)] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("remove-money")
        .setDescription("Remove money from a member's balance")
        .addUserOption((o) => o.setName("member").setDescription("Member").setRequired(true))
        .addNumberOption((o) => o.setName("amount").setDescription("Amount").setRequired(true).setMinValue(0.01))
        .addStringOption((o) =>
          o.setName("type").setDescription("cash or bank (default: cash)")
            .addChoices({ name: "Cash", value: "cash" }, { name: "Bank", value: "bank" }),
        ),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        if (!isAdmin(i)) return noPerm(i);
        const target = i.options.getUser("member", true);
        const amount = i.options.getNumber("amount", true);
        const type = (i.options.getString("type") ?? "cash") as "cash" | "bank";
        await getOrCreateWallet(i.guildId, target.id);
        const { success, wallet } = await removeMoney(i.guildId, target.id, type, amount);
        const config = await getConfig(i.guildId);
        if (!success) return i.reply({ content: `**${target.displayName}** doesn't have enough ${type}.`, ephemeral: true });
        await logAudit(i.guildId, target.id, `remove_${type}`, amount, i.user.id);
        await sendAuditLog(client, i.guildId, `💸 **${i.user.displayName}** removed ${fmt(config, amount)} ${type} from **${target.displayName}** | Remaining: ${fmt(config, wallet[type])}`);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setTitle("Money Removed").addFields({ name: "Member", value: `${target}`, inline: true }, { name: type === "cash" ? "New Cash" : "New Bank", value: fmt(config, wallet[type]), inline: true })] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("remove-money-role")
        .setDescription("Remove money from all members with a role")
        .addRoleOption((o) => o.setName("role").setDescription("Role").setRequired(true))
        .addNumberOption((o) => o.setName("amount").setDescription("Amount").setRequired(true).setMinValue(0.01))
        .addStringOption((o) =>
          o.setName("type").setDescription("cash or bank (default: cash)")
            .addChoices({ name: "Cash", value: "cash" }, { name: "Bank", value: "bank" }),
        ),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        if (!isAdmin(i)) return noPerm(i);
        if (!i.guild) return guildOnly(i);
        const role = i.options.getRole("role", true);
        const amount = i.options.getNumber("amount", true);
        const type = (i.options.getString("type") ?? "cash") as "cash" | "bank";
        await i.deferReply();
        const members = await i.guild.members.fetch();
        const config = await getConfig(i.guildId);
        let count = 0;
        for (const [, member] of members) {
          if (member.user.bot) continue;
          if (member.roles.cache.has(role.id)) {
            const w = await getOrCreateWallet(i.guildId, member.id);
            if (parseFloat(w[type]) >= amount) {
              await removeMoney(i.guildId, member.id, type, amount);
              count++;
            }
          }
        }
        await sendAuditLog(client, i.guildId, `💸 **${i.user.displayName}** removed ${fmt(config, amount)} ${type} from **${count}** members with role @${role.name}`);
        return i.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setTitle("Money Removed from Role").setDescription(`Removed **${fmt(config, amount)}** ${type} from **${count}** members with <@&${role.id}>`)] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("deposit")
        .setDescription("Deposit cash into your bank")
        .addStringOption((o) => o.setName("amount").setDescription('Amount to deposit or "all"').setRequired(true)),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        const raw = i.options.getString("amount", true);
        const wallet = await getOrCreateWallet(i.guildId, i.user.id);
        const cash = parseFloat(wallet.cash);
        const amount = parseAmount(raw, cash);
        if (!amount) return i.reply({ content: "Enter a valid amount or \"all\".", ephemeral: true });
        if (amount > cash) return i.reply({ content: "You don't have that much cash.", ephemeral: true });
        const config = await getConfig(i.guildId);
        if (config.max_bank) {
          const bank = parseFloat(wallet.bank);
          if (bank + amount > parseFloat(config.max_bank))
            return i.reply({ content: `Deposit would exceed max bank balance of **${fmt(config, config.max_bank)}**.`, ephemeral: true });
        }
        await removeMoney(i.guildId, i.user.id, "cash", amount);
        const updated = await addMoney(i.guildId, i.user.id, "bank", amount);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Deposit Successful").addFields({ name: "Deposited", value: fmt(config, amount), inline: true }, { name: "Cash", value: fmt(config, updated.cash), inline: true }, { name: "Bank", value: fmt(config, updated.bank), inline: true })] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("withdraw")
        .setDescription("Withdraw from your bank")
        .addStringOption((o) => o.setName("amount").setDescription('Amount to withdraw or "all"').setRequired(true)),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        const raw = i.options.getString("amount", true);
        const wallet = await getOrCreateWallet(i.guildId, i.user.id);
        const bank = parseFloat(wallet.bank);
        const amount = parseAmount(raw, bank);
        if (!amount) return i.reply({ content: "Enter a valid amount or \"all\".", ephemeral: true });
        if (amount > bank) return i.reply({ content: "You don't have that much in the bank.", ephemeral: true });
        const config = await getConfig(i.guildId);
        if (config.max_cash) {
          const cash = parseFloat(wallet.cash);
          if (cash + amount > parseFloat(config.max_cash))
            return i.reply({ content: `Withdrawal would exceed max cash balance of **${fmt(config, config.max_cash)}**.`, ephemeral: true });
        }
        await removeMoney(i.guildId, i.user.id, "bank", amount);
        const updated = await addMoney(i.guildId, i.user.id, "cash", amount);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Withdrawal Successful").addFields({ name: "Withdrawn", value: fmt(config, amount), inline: true }, { name: "Cash", value: fmt(config, updated.cash), inline: true }, { name: "Bank", value: fmt(config, updated.bank), inline: true })] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("give-money")
        .setDescription("Give your cash to another member")
        .addUserOption((o) => o.setName("member").setDescription("Member to give to").setRequired(true))
        .addStringOption((o) => o.setName("amount").setDescription('Amount or "all"').setRequired(true)),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        const target = i.options.getUser("member", true);
        if (target.id === i.user.id) return i.reply({ content: "You can't give money to yourself.", ephemeral: true });
        if (target.bot) return i.reply({ content: "Can't give money to bots.", ephemeral: true });
        const wallet = await getOrCreateWallet(i.guildId, i.user.id);
        const cash = parseFloat(wallet.cash);
        const raw = i.options.getString("amount", true);
        const amount = parseAmount(raw, cash);
        if (!amount) return i.reply({ content: "Enter a valid amount or \"all\".", ephemeral: true });
        const config = await getConfig(i.guildId);
        const result = await transferCash(i.guildId, i.user.id, target.id, amount);
        if (!result.success) return i.reply({ content: result.reason ?? "Transfer failed.", ephemeral: true });
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Money Sent").setDescription(`You gave **${fmt(config, amount)}** to ${target}`)] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("money")
        .setDescription("Check your or another member's balance")
        .addUserOption((o) => o.setName("user").setDescription("Member to check (default: you)")),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        const target = i.options.getUser("user") ?? i.user;
        const wallet = await getOrCreateWallet(i.guildId, target.id);
        const config = await getConfig(i.guildId);
        const embed = new EmbedBuilder()
          .setColor(0xfee75c)
          .setTitle(`${target.displayName}'s Wallet`)
          .setThumbnail(target.displayAvatarURL())
          .addFields(
            { name: "Cash", value: fmt(config, wallet.cash), inline: true },
            { name: "Bank", value: fmt(config, wallet.bank), inline: true },
            { name: "Total", value: fmt(config, parseFloat(wallet.cash) + parseFloat(wallet.bank)), inline: true },
          );
        return i.reply({ embeds: [embed] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("leaderboard")
        .setDescription("View the richest members")
        .addIntegerOption((o) => o.setName("page").setDescription("Page").setMinValue(1))
        .addStringOption((o) =>
          o.setName("sort").setDescription("Sort by").addChoices(
            { name: "Cash", value: "cash" },
            { name: "Bank", value: "bank" },
            { name: "Total (default)", value: "total" },
          ),
        ),
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        const page = Math.max(1, i.options.getInteger("page") ?? 1);
        const sort = (i.options.getString("sort") ?? "total") as "cash" | "bank" | "total";
        const perPage = 10;
        const total = await countLeaderboard(i.guildId);
        const totalPages = Math.max(1, Math.ceil(total / perPage));
        const cur = Math.min(page, totalPages);
        const rows = await getLeaderboard(i.guildId, sort, perPage, (cur - 1) * perPage);
        const config = await getConfig(i.guildId);
        const embed = new EmbedBuilder()
          .setColor(0xfee75c)
          .setTitle(`Leaderboard — Top ${sort === "total" ? "Total" : sort === "cash" ? "Cash" : "Bank"}`)
          .setFooter({ text: `Page ${cur} of ${totalPages}` });
        const offset = (cur - 1) * perPage;
        rows.forEach((r, idx) => {
          const rank = offset + idx + 1;
          const medal = rank === 1 ? "🥇" : rank === 2 ? "🥈" : rank === 3 ? "🥉" : `#${rank}`;
          const val = sort === "total" ? fmt(config, r.total) : sort === "cash" ? fmt(config, r.cash) : fmt(config, r.bank);
          embed.addFields({ name: `${medal} <@${r.user_id}>`, value: val, inline: false });
        });
        if (rows.length === 0) embed.setDescription("No data yet.");
        return i.reply({ embeds: [embed] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("reset-money")
        .setDescription("Reset a member's balance to starting balance")
        .addUserOption((o) => o.setName("user").setDescription("Member to reset (leave blank to reset everyone)"))
        ,
      async execute(i: ChatInputCommandInteraction) {
        if (!i.guildId) return guildOnly(i);
        if (!isAdmin(i)) return noPerm(i);
        const target = i.options.getUser("user");
        if (target) {
          await resetWallet(i.guildId, target.id);
          return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`Reset **${target.displayName}**'s balance to starting balance.`)] });
        }
        const config = await getConfig(i.guildId);
        await pool.query(
          `UPDATE wallets SET cash=$1, bank=0 WHERE guild_id=$2`,
          [config.start_balance, i.guildId],
        );
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("Reset **all** member balances to starting balance.")] });
      },
    },
  ];
}

