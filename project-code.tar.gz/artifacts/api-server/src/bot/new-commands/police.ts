import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  GuildMember,
  type ChatInputCommandInteraction,
} from "discord.js";
import {
  getCivilianByName,
  getVehicle,
  getFirearm,
  getFlags,
  addFlag,
  removeFlag,
  issueBolo,
  clearBolo,
  checkBolo,
  addCase,
  lookupCase,
  getEvidence,
  addEvidence,
  getOfficerStatus,
  updateOfficerStatus,
  setVehicleImpound,
} from "../character-db.js";
import { getOrCreateWallet, removeMoney, getConfig, fmt } from "../economy-db.js";
import { getUserInventory } from "../db.js";

function isAdmin(i: ChatInputCommandInteraction): boolean {
  const m = i.member;
  if (!m) return false;
  if (m instanceof GuildMember) {
    if (m.permissions.has(PermissionFlagsBits.ManageGuild)) return true;
    if (m.roles.cache.some((r) => r.name.toLowerCase() === "bot commander")) return true;
  } else {
    const p = BigInt(m.permissions as string);
    if ((p & PermissionFlagsBits.ManageGuild) === PermissionFlagsBits.ManageGuild) return true;
  }
  return false;
}

function guildOnly(i: ChatInputCommandInteraction) {
  return i.reply({ content: "Server only.", ephemeral: true });
}

export const policeCommands = [
  {
    data: new SlashCommandBuilder()
      .setName("arrest")
      .setDescription("Arrest a civilian character")
      .addStringOption((o) => o.setName("name").setDescription("Civilian full name").setRequired(true))
      .addStringOption((o) => o.setName("charges").setDescription("Charges").setRequired(true))
      .addStringOption((o) => o.setName("time").setDescription("Sentence (e.g. 30 months)").setRequired(true))
      .addUserOption((o) => o.setName("user").setDescription("Discord user (optional)"))
      .addNumberOption((o) => o.setName("fine").setDescription("Fine amount").setMinValue(0)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const name = i.options.getString("name", true);
      const charges = i.options.getString("charges", true);
      const time = i.options.getString("time", true);
      const fine = i.options.getNumber("fine");
      const target = i.options.getUser("user");
      const caseId = await addCase(i.guildId, "arrest", name, i.user.id, charges, fine ?? undefined, time);
      if (target && i.guildId && fine) {
        const { success } = await removeMoney(i.guildId, target.id, "cash", fine);
        const config = await getConfig(i.guildId);
        const embed = new EmbedBuilder()
          .setColor(0xed4245)
          .setTitle("Arrest Report")
          .setDescription(`**Case #${caseId}**`)
          .addFields(
            { name: "Civilian", value: name, inline: true },
            { name: "Officer", value: `${i.user}`, inline: true },
            { name: "Charges", value: charges, inline: false },
            { name: "Sentence", value: time, inline: true },
            { name: "Fine", value: fine ? `${fmt(config, fine)}${!success ? " *(insufficient funds)*" : ""}` : "None", inline: true },
          );
        return i.reply({ embeds: [embed] });
      }
      const embed = new EmbedBuilder()
        .setColor(0xed4245).setTitle("Arrest Report").setDescription(`**Case #${caseId}**`)
        .addFields({ name: "Civilian", value: name, inline: true }, { name: "Officer", value: `${i.user}`, inline: true }, { name: "Charges", value: charges, inline: false }, { name: "Sentence", value: time, inline: true });
      return i.reply({ embeds: [embed] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("bodycam")
      .setDescription("Activate or deactivate your bodycam")
      .addSubcommand((s) => s.setName("activate").setDescription("Activate bodycam"))
      .addSubcommand((s) => s.setName("deactivate").setDescription("Deactivate bodycam")),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const sub = i.options.getSubcommand();
      const on = sub === "activate";
      await updateOfficerStatus(i.user.id, i.guildId, "bodycam_active", on);
      return i.reply({
        embeds: [new EmbedBuilder().setColor(on ? 0x57f287 : 0xed4245)
          .setDescription(`🎥 Bodycam **${on ? "activated" : "deactivated"}** for ${i.user}.`)],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("bolo")
      .setDescription("BOLO (Be On Look Out) commands")
      .addSubcommand((s) =>
        s.setName("issue").setDescription("Issue a BOLO")
          .addStringOption((o) => o.setName("name").setDescription("Civilian name").setRequired(true))
          .addStringOption((o) => o.setName("reason").setDescription("Reason").setRequired(true)),
      )
      .addSubcommand((s) =>
        s.setName("clear").setDescription("Clear a BOLO")
          .addStringOption((o) => o.setName("name").setDescription("Civilian name").setRequired(true)),
      )
      .addSubcommand((s) =>
        s.setName("check").setDescription("Check if a civilian has a BOLO")
          .addStringOption((o) => o.setName("name").setDescription("Civilian name").setRequired(true)),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const sub = i.options.getSubcommand();
      const name = i.options.getString("name", true);
      if (sub === "issue") {
        const reason = i.options.getString("reason", true);
        const id = await issueBolo(i.guildId, name, reason, i.user.id);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xfee75c).setTitle("BOLO Issued").setDescription(`**BOLO #${id}** — **${name}**\n*${reason}*\nIssued by ${i.user}`)] });
      }
      if (sub === "clear") {
        const cleared = await clearBolo(i.guildId, name);
        return i.reply({ embeds: [new EmbedBuilder().setColor(cleared ? 0x57f287 : 0xed4245).setDescription(cleared ? `BOLO for **${name}** cleared.` : `No active BOLO found for **${name}**.`)] });
      }
      if (sub === "check") {
        const bolo = await checkBolo(i.guildId, name);
        if (!bolo) return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`No active BOLO for **${name}**.`)] });
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setTitle("BOLO Active").addFields({ name: "Civilian", value: name, inline: true }, { name: "Reason", value: bolo.reason, inline: false })] });
      }
      return;
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("breathalyser")
      .setDescription("Breathalyse a person")
      .addUserOption((o) => o.setName("user").setDescription("Person to test").setRequired(true)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const target = i.options.getUser("user", true);
      const bac = (Math.random() * 0.25).toFixed(3);
      const level = parseFloat(bac);
      const color = level === 0 ? 0x57f287 : level < 0.08 ? 0xfee75c : 0xed4245;
      const status = level === 0 ? "Sober" : level < 0.08 ? "Slightly Impaired" : level < 0.15 ? "Impaired — Over Legal Limit" : "Heavily Impaired";
      return i.reply({ embeds: [new EmbedBuilder().setColor(color).setTitle("Breathalyser Result").addFields({ name: "Subject", value: `${target}`, inline: true }, { name: "BAC", value: `${bac}%`, inline: true }, { name: "Status", value: status, inline: true })] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("cctv")
      .setDescription("Check video surveillance of an area")
      .addStringOption((o) => o.setName("area").setDescription("Area to check").setRequired(true)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const area = i.options.getString("area", true);
      const status = await getOfficerStatus(i.user.id, i.guildId);
      if (!status.on_duty) return i.reply({ content: "You must be on duty to access CCTV.", ephemeral: true });
      return i.reply({ embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle(`CCTV — ${area}`).setDescription(`*Accessing surveillance footage for **${area}**...*\n\n📹 Footage reviewed by ${i.user}.\n\nDocument your findings in your report.`)] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("cite")
      .setDescription("Issue a citation to a civilian")
      .addStringOption((o) => o.setName("name").setDescription("Civilian name").setRequired(true))
      .addStringOption((o) => o.setName("charges").setDescription("Violation").setRequired(true))
      .addNumberOption((o) => o.setName("fine").setDescription("Fine amount").setRequired(true).setMinValue(0))
      .addUserOption((o) => o.setName("user").setDescription("Discord user (optional)")),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const name = i.options.getString("name", true);
      const charges = i.options.getString("charges", true);
      const fine = i.options.getNumber("fine", true);
      const target = i.options.getUser("user");
      const caseId = await addCase(i.guildId, "citation", name, i.user.id, charges, fine);
      if (target && i.guildId) {
        const { success } = await removeMoney(i.guildId, target.id, "cash", fine);
        const config = await getConfig(i.guildId);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xfee75c).setTitle("Citation Issued").setDescription(`**Case #${caseId}**`).addFields({ name: "Civilian", value: name, inline: true }, { name: "Violation", value: charges, inline: true }, { name: "Fine", value: `${fmt(config, fine)}${!success ? " *(insufficient funds)*" : ""}`, inline: true })] });
      }
      return i.reply({ embeds: [new EmbedBuilder().setColor(0xfee75c).setTitle("Citation Issued").setDescription(`**Case #${caseId}**`).addFields({ name: "Civilian", value: name, inline: true }, { name: "Violation", value: charges, inline: true })] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("confiscate")
      .setDescription("Confiscate an item from a user")
      .addUserOption((o) => o.setName("user").setDescription("User to confiscate from").setRequired(true))
      .addStringOption((o) => o.setName("item").setDescription("Item name to confiscate").setRequired(true))
      .addIntegerOption((o) => o.setName("quantity").setDescription("Quantity").setMinValue(1)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const target = i.options.getUser("user", true);
      const itemName = i.options.getString("item", true);
      const qty = i.options.getInteger("quantity") ?? 1;
      await addEvidence(i.guildId, target.id, itemName, qty, i.user.id);
      const { removeFromInventory, getItemByName } = await import("../db.js");
      const item = await getItemByName(itemName);
      if (item) await removeFromInventory(target.id, item.id, qty).catch(() => null);
      return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setTitle("Item Confiscated").setDescription(`Confiscated **${qty}x ${itemName}** from ${target}.`)] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("cuff")
      .setDescription("Handcuff a person")
      .addUserOption((o) => o.setName("user").setDescription("Person to cuff").setRequired(true)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const target = i.options.getUser("user", true);
      return i.reply({ embeds: [new EmbedBuilder().setColor(0xfee75c).setDescription(`*${i.user.displayName} handcuffs ${target.displayName}. 🔗*`)] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("uncuff")
      .setDescription("Remove handcuffs from a person")
      .addUserOption((o) => o.setName("user").setDescription("Person to uncuff").setRequired(true)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const target = i.options.getUser("user", true);
      return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`*${i.user.displayName} removes handcuffs from ${target.displayName}.*`)] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("evidence")
      .setDescription("View confiscated items from a user")
      .addUserOption((o) => o.setName("user").setDescription("User to check").setRequired(true)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const target = i.options.getUser("user", true);
      const evidence = await getEvidence(i.guildId, target.id);
      if (!evidence.length) return i.reply({ content: `No evidence recorded for ${target.displayName}.`, ephemeral: true });
      const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`Evidence — ${target.displayName}`);
      for (const e of evidence) {
        embed.addFields({ name: `${e.item_name} × ${e.quantity}`, value: `Confiscated by <@${e.confiscated_by}>`, inline: true });
      }
      return i.reply({ embeds: [embed] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("fine")
      .setDescription("Fine a civilian character")
      .addStringOption((o) => o.setName("name").setDescription("Civilian name").setRequired(true))
      .addStringOption((o) => o.setName("charges").setDescription("Infraction").setRequired(true))
      .addNumberOption((o) => o.setName("cost").setDescription("Fine amount").setRequired(true).setMinValue(0))
      .addUserOption((o) => o.setName("user").setDescription("Discord user (optional)")),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const name = i.options.getString("name", true);
      const charges = i.options.getString("charges", true);
      const cost = i.options.getNumber("cost", true);
      const target = i.options.getUser("user");
      const caseId = await addCase(i.guildId, "fine", name, i.user.id, charges, cost);
      let deducted = false;
      if (target && i.guildId) {
        const { success } = await removeMoney(i.guildId, target.id, "cash", cost);
        deducted = success;
      }
      const config = await getConfig(i.guildId);
      return i.reply({ embeds: [new EmbedBuilder().setColor(0xfee75c).setTitle("Fine Issued").setDescription(`**Case #${caseId}**`).addFields({ name: "Civilian", value: name, inline: true }, { name: "Infraction", value: charges, inline: true }, { name: "Cost", value: `${fmt(config, cost)}${target && !deducted ? " *(insufficient funds)*" : ""}`, inline: true })] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("flag")
      .setDescription("Add or remove a flag on a civilian")
      .addSubcommand((s) =>
        s.setName("add").setDescription("Add a flag")
          .addStringOption((o) => o.setName("name").setDescription("Civilian name").setRequired(true))
          .addStringOption((o) =>
            o.setName("type").setDescription("Flag type").setRequired(true)
              .addChoices(
                { name: "Armed & Dangerous", value: "Armed & Dangerous" },
                { name: "Warrant", value: "Warrant" },
                { name: "Known Gang Member", value: "Known Gang Member" },
                { name: "Drug Offender", value: "Drug Offender" },
                { name: "Repeat Offender", value: "Repeat Offender" },
                { name: "Violent", value: "Violent" },
              ),
          ),
      )
      .addSubcommand((s) =>
        s.setName("remove").setDescription("Remove a flag")
          .addStringOption((o) => o.setName("name").setDescription("Civilian name").setRequired(true))
          .addStringOption((o) => o.setName("type").setDescription("Flag type").setRequired(true)),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const sub = i.options.getSubcommand();
      const name = i.options.getString("name", true);
      const type = i.options.getString("type", true);
      const civ = await getCivilianByName(i.guildId, name);
      if (!civ) return i.reply({ content: `Civilian "${name}" not found.`, ephemeral: true });
      if (sub === "add") {
        await addFlag(civ.id, type);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`Flag **${type}** added to **${name}**.`)] });
      }
      const removed = await removeFlag(civ.id, type);
      return i.reply({ embeds: [new EmbedBuilder().setColor(removed ? 0x57f287 : 0xfee75c).setDescription(removed ? `Flag **${type}** removed from **${name}**.` : `Flag **${type}** not found on **${name}**.`)] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("impound")
      .setDescription("Impound or release a vehicle")
      .addSubcommand((s) =>
        s.setName("add").setDescription("Impound a vehicle")
          .addStringOption((o) => o.setName("plate").setDescription("License plate").setRequired(true))
          .addNumberOption((o) => o.setName("fee").setDescription("Impound fee").setMinValue(0)),
      )
      .addSubcommand((s) =>
        s.setName("remove").setDescription("Release a vehicle from impound")
          .addStringOption((o) => o.setName("plate").setDescription("License plate").setRequired(true)),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const sub = i.options.getSubcommand();
      const plate = i.options.getString("plate", true).toUpperCase();
      if (sub === "add") {
        const fee = i.options.getNumber("fee");
        const ok = await setVehicleImpound(plate, true, fee ?? undefined);
        if (!ok) return i.reply({ content: `Vehicle **${plate}** not found.`, ephemeral: true });
        const config = await getConfig(i.guildId);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setTitle("Vehicle Impounded").addFields({ name: "Plate", value: plate, inline: true }, { name: "Fee", value: fee ? fmt(config, fee) : "None", inline: true })] });
      }
      const ok = await setVehicleImpound(plate, false);
      if (!ok) return i.reply({ content: `Vehicle **${plate}** not found.`, ephemeral: true });
      return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`Vehicle **${plate}** released from impound.`)] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("lookup")
      .setDescription("Lookup vehicle, firearm, civilian, or case information")
      .addSubcommand((s) =>
        s.setName("vehicle").setDescription("Lookup a vehicle by plate")
          .addStringOption((o) => o.setName("plate").setDescription("License plate").setRequired(true)),
      )
      .addSubcommand((s) =>
        s.setName("firearm").setDescription("Lookup a firearm by serial number")
          .addStringOption((o) => o.setName("serial_number").setDescription("Serial number").setRequired(true)),
      )
      .addSubcommand((s) =>
        s.setName("civilian").setDescription("Lookup a civilian character")
          .addStringOption((o) => o.setName("name").setDescription("Civilian full name").setRequired(true)),
      )
      .addSubcommand((s) =>
        s.setName("case").setDescription("Lookup a case by ID")
          .addIntegerOption((o) => o.setName("id").setDescription("Case ID").setRequired(true))
          .addStringOption((o) =>
            o.setName("type").setDescription("Case type")
              .addChoices({ name: "Arrest", value: "arrest" }, { name: "Fine", value: "fine" }, { name: "Citation", value: "citation" }),
          ),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const sub = i.options.getSubcommand();

      if (sub === "vehicle") {
        const v = await getVehicle(i.options.getString("plate", true));
        if (!v) return i.reply({ content: "Vehicle not found.", ephemeral: true });
        const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`Vehicle Lookup — ${v.plate}`)
          .addFields({ name: "Model", value: v.model, inline: true }, { name: "Color", value: `${v.color} (${v.color_type})`, inline: true }, { name: "Insurance", value: v.insurance, inline: true }, { name: "Registration", value: v.registration, inline: true }, { name: "Impounded", value: v.is_impounded ? `Yes (Fee: ${v.impound_fee ?? "N/A"})` : "No", inline: true });
        return i.reply({ embeds: [embed] });
      }
      if (sub === "firearm") {
        const f = await getFirearm(i.options.getString("serial_number", true));
        if (!f) return i.reply({ content: "Firearm not found.", ephemeral: true });
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle("Firearm Lookup").addFields({ name: "Serial", value: f.serial_number, inline: true }, { name: "Model", value: f.model, inline: true }, { name: "Color", value: f.color, inline: true })] });
      }
      if (sub === "civilian") {
        const civ = await getCivilianByName(i.guildId, i.options.getString("name", true));
        if (!civ) return i.reply({ content: "Civilian not found.", ephemeral: true });
        const flags = await getFlags(civ.id);
        const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`Civilian Lookup — ${civ.forename} ${civ.surname}`)
          .addFields({ name: "DOB", value: civ.date_of_birth, inline: true }, { name: "Gender", value: civ.gender, inline: true }, { name: "Blood Type", value: civ.blood_type, inline: true }, { name: "Occupation", value: civ.occupation, inline: true }, { name: "Address", value: civ.address, inline: false }, { name: "Flags", value: flags.length ? flags.join(", ") : "None", inline: false });
        return i.reply({ embeds: [embed] });
      }
      if (sub === "case") {
        const id = i.options.getInteger("id", true);
        const type = i.options.getString("type") ?? undefined;
        const c = await lookupCase(i.guildId, id, type);
        if (!c) return i.reply({ content: `Case #${id} not found.`, ephemeral: true });
        const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`Case #${id} — ${c.case_type.toUpperCase()}`)
          .addFields({ name: "Civilian", value: c.civilian_name, inline: true }, { name: "Officer", value: `<@${c.officer_id}>`, inline: true });
        if (c.charges) embed.addFields({ name: "Charges", value: c.charges, inline: false });
        if (c.cost) embed.addFields({ name: "Cost", value: String(c.cost), inline: true });
        if (c.notes) embed.addFields({ name: "Notes", value: c.notes, inline: false });
        return i.reply({ embeds: [embed] });
      }
      return;
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("radar")
      .setDescription("Record a radar speed reading")
      .addNumberOption((o) => o.setName("speed").setDescription("Detected speed (mph)").setRequired(true).setMinValue(0)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const speed = i.options.getNumber("speed", true);
      const limit = 35;
      const over = speed > limit;
      return i.reply({
        embeds: [new EmbedBuilder().setColor(over ? 0xed4245 : 0x57f287).setTitle("Radar Reading")
          .addFields({ name: "Detected Speed", value: `${speed} mph`, inline: true }, { name: "Speed Limit", value: `${limit} mph`, inline: true }, { name: "Status", value: over ? `⚠️ Over limit by ${(speed - limit).toFixed(0)} mph` : "✅ Within limit", inline: true })],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("search")
      .setDescription("Search a person or vehicle")
      .addSubcommand((s) =>
        s.setName("person").setDescription("Search a civilian")
          .addUserOption((o) => o.setName("user").setDescription("Person to search").setRequired(true)),
      )
      .addSubcommand((s) =>
        s.setName("vehicle").setDescription("Search a civilian's vehicle")
          .addUserOption((o) => o.setName("user").setDescription("Vehicle owner").setRequired(true)),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const sub = i.options.getSubcommand();
      const target = i.options.getUser("user", true);
      if (sub === "person") {
        const items = await getUserInventory(target.id, 25, 0);
        const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`Search — ${target.displayName}`)
          .setDescription(items.length ? `Found **${items.length}** item(s) on person.` : "Nothing found on person.");
        for (const row of items) embed.addFields({ name: `${row.name} × ${row.quantity}`, value: row.description || "No description", inline: true });
        return i.reply({ embeds: [embed] });
      }
      const civ = await import("../character-db.js").then((m) => m.getActiveCivilian(target.id, i.guildId!));
      if (!civ) return i.reply({ content: `${target.displayName} has no active character.`, ephemeral: true });
      const { pool } = await import("@workspace/db");
      const vRes = await pool.query("SELECT * FROM vehicles WHERE civilian_id=$1", [civ.id]);
      const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`Vehicle Search — ${target.displayName}`);
      if (!vRes.rows.length) embed.setDescription("No registered vehicles found.");
      for (const v of vRes.rows) embed.addFields({ name: v.plate, value: `${v.model} — ${v.color} | Insurance: ${v.insurance} | Reg: ${v.registration}${v.is_impounded ? " | ⚠️ IMPOUNDED" : ""}`, inline: false });
      return i.reply({ embeds: [embed] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("tackle")
      .setDescription("Tackle and restrain a user")
      .addUserOption((o) => o.setName("user").setDescription("Person to tackle").setRequired(true)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const target = i.options.getUser("user", true);
      const success = Math.random() < 0.8;
      return i.reply({
        embeds: [new EmbedBuilder().setColor(success ? 0xed4245 : 0xfee75c)
          .setDescription(success ? `*${i.user.displayName} tackles ${target.displayName} to the ground and restrains them.*` : `*${i.user.displayName} attempts to tackle ${target.displayName} but misses!*`)],
      });
    },
  },
];
