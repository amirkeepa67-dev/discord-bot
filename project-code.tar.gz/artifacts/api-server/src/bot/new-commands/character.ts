import {
  SlashCommandBuilder,
  EmbedBuilder,
  type ChatInputCommandInteraction,
} from "discord.js";
import {
  createCivilian,
  getCivilian,
  getActiveCivilian,
  listCivilians,
  setActiveCivilian,
  editCivilian,
  deleteCivilian,
  registerFirearm,
  getFirearm,
  editFirearm,
  deleteFirearm,
  registerVehicle,
  getVehicle,
  editVehicle,
  deleteVehicle,
} from "../character-db.js";

function guildOnly(i: ChatInputCommandInteraction) {
  return i.reply({ content: "Server only.", ephemeral: true });
}

export const characterCommands = [
  // ── CIVILIAN ────────────────────────────────────────────────────────────
  {
    data: new SlashCommandBuilder()
      .setName("civilian")
      .setDescription("Civilian character management")
      .addSubcommand((s) =>
        s.setName("list").setDescription("List all your civilian characters"),
      )
      .addSubcommand((s) =>
        s
          .setName("create")
          .setDescription("Create a civilian character")
          .addStringOption((o) => o.setName("forename").setDescription("First name").setRequired(true))
          .addStringOption((o) => o.setName("surname").setDescription("Last name").setRequired(true))
          .addStringOption((o) => o.setName("date_of_birth").setDescription("Date of birth (MM/DD/YYYY)").setRequired(true))
          .addStringOption((o) =>
            o.setName("gender").setDescription("Gender").setRequired(true)
              .addChoices({ name: "Male", value: "Male" }, { name: "Female", value: "Female" }, { name: "Other", value: "Other" }),
          )
          .addStringOption((o) => o.setName("hair_color").setDescription("Hair color").setRequired(true))
          .addStringOption((o) =>
            o.setName("blood_type").setDescription("Blood type").setRequired(true)
              .addChoices(
                { name: "A+", value: "A+" }, { name: "A-", value: "A-" },
                { name: "B+", value: "B+" }, { name: "B-", value: "B-" },
                { name: "O+", value: "O+" }, { name: "O-", value: "O-" },
                { name: "AB+", value: "AB+" }, { name: "AB-", value: "AB-" },
              ),
          )
          .addStringOption((o) => o.setName("height").setDescription("Height (e.g. 5'11\")").setRequired(true))
          .addStringOption((o) => o.setName("weight").setDescription("Weight (e.g. 180 lbs)").setRequired(true))
          .addStringOption((o) => o.setName("address").setDescription("Home address").setRequired(true))
          .addStringOption((o) => o.setName("occupation").setDescription("Occupation").setRequired(true)),
      )
      .addSubcommand((s) =>
        s
          .setName("set_active")
          .setDescription("Set a civilian as your active character")
          .addStringOption((o) => o.setName("name").setDescription("Full name").setRequired(true)),
      )
      .addSubcommand((s) =>
        s.setName("remove_active").setDescription("Remove your active character"),
      )
      .addSubcommand((s) =>
        s
          .setName("info")
          .setDescription("View a civilian's info")
          .addStringOption((o) => o.setName("name").setDescription("Full name").setRequired(true)),
      )
      .addSubcommand((s) =>
        s
          .setName("delete")
          .setDescription("Permanently delete a civilian character")
          .addStringOption((o) => o.setName("name").setDescription("Full name").setRequired(true)),
      )
      .addSubcommand((s) =>
        s
          .setName("edit")
          .setDescription("Edit a field on your civilian")
          .addStringOption((o) =>
            o.setName("field").setDescription("Field to edit").setRequired(true)
              .addChoices(
                { name: "First Name", value: "forename" },
                { name: "Last Name", value: "surname" },
                { name: "Date of Birth", value: "date_of_birth" },
                { name: "Gender", value: "gender" },
                { name: "Hair Color", value: "hair_color" },
                { name: "Blood Type", value: "blood_type" },
                { name: "Height", value: "height" },
                { name: "Weight", value: "weight" },
                { name: "Address", value: "address" },
                { name: "Occupation", value: "occupation" },
              ),
          )
          .addStringOption((o) => o.setName("value").setDescription("New value").setRequired(true))
          .addStringOption((o) => o.setName("name").setDescription("Character full name").setRequired(true)),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const sub = i.options.getSubcommand();

      if (sub === "list") {
        const civs = await listCivilians(i.user.id, i.guildId);
        if (!civs.length)
          return i.reply({ content: "You have no civilian characters. Use `/civilian create` to make one.", ephemeral: true });
        const embed = new EmbedBuilder().setColor(0x5865f2).setTitle("Your Civilian Characters");
        for (const c of civs) {
          embed.addFields({
            name: `${c.is_active ? "✅ " : ""}${c.forename} ${c.surname}`,
            value: `📱 ${c.phone_number ?? "No number"} | ${c.occupation}`,
          });
        }
        return i.reply({ embeds: [embed], ephemeral: true });
      }

      if (sub === "create") {
        const civ = await createCivilian(i.user.id, i.guildId, {
          forename: i.options.getString("forename", true),
          surname: i.options.getString("surname", true),
          date_of_birth: i.options.getString("date_of_birth", true),
          gender: i.options.getString("gender", true),
          hair_color: i.options.getString("hair_color", true),
          blood_type: i.options.getString("blood_type", true),
          height: i.options.getString("height", true),
          weight: i.options.getString("weight", true),
          address: i.options.getString("address", true),
          occupation: i.options.getString("occupation", true),
        });
        const embed = new EmbedBuilder()
          .setColor(0x57f287)
          .setTitle("Character Created")
          .addFields(
            { name: "Name", value: `${civ.forename} ${civ.surname}`, inline: true },
            { name: "Phone Number", value: civ.phone_number ?? "N/A", inline: true },
            { name: "DOB", value: civ.date_of_birth, inline: true },
            { name: "Gender", value: civ.gender, inline: true },
            { name: "Blood Type", value: civ.blood_type, inline: true },
            { name: "Occupation", value: civ.occupation, inline: true },
            { name: "Address", value: civ.address, inline: false },
          )
          .setFooter({ text: "Use /civilian set_active to activate this character." });
        return i.reply({ embeds: [embed], ephemeral: true });
      }

      if (sub === "set_active") {
        const name = i.options.getString("name", true);
        const civ = await getCivilian(i.user.id, i.guildId, name);
        if (!civ) return i.reply({ content: `No character named "${name}" found.`, ephemeral: true });
        await setActiveCivilian(i.user.id, i.guildId, civ.id);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`**${civ.forename} ${civ.surname}** is now your active character.`)], ephemeral: true });
      }

      if (sub === "remove_active") {
        const { pool } = await import("@workspace/db");
        await pool.query(`UPDATE civilians SET is_active=false WHERE user_id=$1 AND guild_id=$2`, [i.user.id, i.guildId]);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("Active character removed.")], ephemeral: true });
      }

      if (sub === "info") {
        const name = i.options.getString("name", true);
        const civ = await getCivilian(i.user.id, i.guildId, name);
        if (!civ) return i.reply({ content: `No character named "${name}" found.`, ephemeral: true });
        const embed = new EmbedBuilder()
          .setColor(0x5865f2)
          .setTitle(`${civ.forename} ${civ.surname}`)
          .addFields(
            { name: "Phone", value: civ.phone_number ?? "N/A", inline: true },
            { name: "DOB", value: civ.date_of_birth, inline: true },
            { name: "Gender", value: civ.gender, inline: true },
            { name: "Hair Color", value: civ.hair_color, inline: true },
            { name: "Blood Type", value: civ.blood_type, inline: true },
            { name: "Height / Weight", value: `${civ.height} / ${civ.weight}`, inline: true },
            { name: "Occupation", value: civ.occupation, inline: true },
            { name: "Address", value: civ.address, inline: false },
          );
        return i.reply({ embeds: [embed], ephemeral: true });
      }

      if (sub === "delete") {
        const name = i.options.getString("name", true);
        const deleted = await deleteCivilian(i.user.id, i.guildId, name);
        if (!deleted) return i.reply({ content: `No character named "${name}" found.`, ephemeral: true });
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`**${name}** has been permanently deleted.`)], ephemeral: true });
      }

      if (sub === "edit") {
        const field = i.options.getString("field", true);
        const value = i.options.getString("value", true);
        const name = i.options.getString("name", true);
        const civ = await getCivilian(i.user.id, i.guildId, name);
        if (!civ) return i.reply({ content: `No character named "${name}" found.`, ephemeral: true });
        await editCivilian(civ.id, field, value);
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`Updated **${field}** to **${value}** for ${name}.`)], ephemeral: true });
      }
      return;
    },
  },

  // ── FIREARM ─────────────────────────────────────────────────────────────
  {
    data: new SlashCommandBuilder()
      .setName("firearm")
      .setDescription("Firearm management")
      .addSubcommand((s) =>
        s
          .setName("register")
          .setDescription("Register a civilian firearm")
          .addStringOption((o) => o.setName("model").setDescription("Firearm model").setRequired(true))
          .addStringOption((o) => o.setName("color").setDescription("Firearm color").setRequired(true))
          .addStringOption((o) => o.setName("name").setDescription("Character name to register under").setRequired(true)),
      )
      .addSubcommand((s) =>
        s
          .setName("info")
          .setDescription("View firearm info")
          .addStringOption((o) => o.setName("serial_number").setDescription("Serial number").setRequired(true)),
      )
      .addSubcommand((s) =>
        s
          .setName("edit")
          .setDescription("Edit a firearm field")
          .addStringOption((o) => o.setName("serial_number").setDescription("Serial number").setRequired(true))
          .addStringOption((o) =>
            o.setName("field").setDescription("Field to edit").setRequired(true)
              .addChoices({ name: "Model", value: "model" }, { name: "Color", value: "color" }, { name: "Name", value: "name" }),
          )
          .addStringOption((o) => o.setName("value").setDescription("New value").setRequired(true)),
      )
      .addSubcommand((s) =>
        s
          .setName("delete")
          .setDescription("Delete a firearm")
          .addStringOption((o) => o.setName("serial_number").setDescription("Serial number").setRequired(true)),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const sub = i.options.getSubcommand();

      if (sub === "register") {
        const charName = i.options.getString("name", true);
        const civ = await getCivilian(i.user.id, i.guildId, charName);
        if (!civ) return i.reply({ content: `No character named "${charName}" found.`, ephemeral: true });
        const firearm = await registerFirearm(civ.id, i.options.getString("model", true), i.options.getString("color", true), charName);
        return i.reply({
          embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Firearm Registered")
            .addFields({ name: "Serial Number", value: firearm.serial_number, inline: true }, { name: "Model", value: firearm.model, inline: true }, { name: "Color", value: firearm.color, inline: true })],
          ephemeral: true,
        });
      }

      if (sub === "info") {
        const serial = i.options.getString("serial_number", true);
        const f = await getFirearm(serial);
        if (!f) return i.reply({ content: "Firearm not found.", ephemeral: true });
        return i.reply({
          embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle("Firearm Info")
            .addFields({ name: "Serial", value: f.serial_number, inline: true }, { name: "Model", value: f.model, inline: true }, { name: "Color", value: f.color, inline: true })],
          ephemeral: true,
        });
      }

      if (sub === "edit") {
        const serial = i.options.getString("serial_number", true);
        const updated = await editFirearm(serial, i.options.getString("field", true), i.options.getString("value", true));
        if (!updated) return i.reply({ content: "Firearm not found.", ephemeral: true });
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`Firearm **${serial}** updated.`)], ephemeral: true });
      }

      if (sub === "delete") {
        const serial = i.options.getString("serial_number", true);
        const deleted = await deleteFirearm(i.user.id, i.guildId, serial);
        if (!deleted) return i.reply({ content: "Firearm not found or not yours.", ephemeral: true });
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`Firearm **${serial}** deleted.`)], ephemeral: true });
      }
      return;
    },
  },

  // ── VEHICLE ─────────────────────────────────────────────────────────────
  {
    data: new SlashCommandBuilder()
      .setName("vehicle")
      .setDescription("Vehicle management")
      .addSubcommand((s) =>
        s
          .setName("register")
          .setDescription("Register a civilian vehicle")
          .addStringOption((o) => o.setName("plate").setDescription("License plate").setRequired(true))
          .addStringOption((o) => o.setName("model").setDescription("Vehicle model").setRequired(true))
          .addStringOption((o) => o.setName("color").setDescription("Vehicle color").setRequired(true))
          .addStringOption((o) =>
            o.setName("color_type").setDescription("Color type").setRequired(true)
              .addChoices({ name: "Solid", value: "solid" }, { name: "Metallic", value: "metallic" }, { name: "Matte", value: "matte" }, { name: "Pearlescent", value: "pearlescent" }),
          )
          .addStringOption((o) =>
            o.setName("insurance").setDescription("Insurance status").setRequired(true)
              .addChoices({ name: "Insured", value: "insured" }, { name: "Uninsured", value: "uninsured" }, { name: "Expired", value: "expired" }),
          )
          .addStringOption((o) =>
            o.setName("registration").setDescription("Registration status").setRequired(true)
              .addChoices({ name: "Valid", value: "valid" }, { name: "Expired", value: "expired" }, { name: "None", value: "none" }),
          )
          .addStringOption((o) => o.setName("name").setDescription("Character name to register under").setRequired(true)),
      )
      .addSubcommand((s) =>
        s
          .setName("info")
          .setDescription("View vehicle info")
          .addStringOption((o) => o.setName("plate").setDescription("License plate").setRequired(true)),
      )
      .addSubcommand((s) =>
        s
          .setName("edit")
          .setDescription("Edit a vehicle field")
          .addStringOption((o) => o.setName("plate").setDescription("License plate").setRequired(true))
          .addStringOption((o) =>
            o.setName("field").setDescription("Field to edit").setRequired(true)
              .addChoices(
                { name: "Model", value: "model" }, { name: "Color", value: "color" },
                { name: "Color Type", value: "color_type" }, { name: "Insurance", value: "insurance" },
                { name: "Registration", value: "registration" },
              ),
          )
          .addStringOption((o) => o.setName("value").setDescription("New value").setRequired(true)),
      )
      .addSubcommand((s) =>
        s
          .setName("delete")
          .setDescription("Delete a vehicle")
          .addStringOption((o) => o.setName("plate").setDescription("License plate").setRequired(true)),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const sub = i.options.getSubcommand();

      if (sub === "register") {
        const charName = i.options.getString("name", true);
        const civ = await getCivilian(i.user.id, i.guildId, charName);
        if (!civ) return i.reply({ content: `No character named "${charName}" found.`, ephemeral: true });
        const existing = await getVehicle(i.options.getString("plate", true));
        if (existing) return i.reply({ content: "A vehicle with that plate already exists.", ephemeral: true });
        const v = await registerVehicle(
          civ.id,
          i.options.getString("plate", true),
          i.options.getString("model", true),
          i.options.getString("color", true),
          i.options.getString("color_type", true),
          i.options.getString("insurance", true),
          i.options.getString("registration", true),
          charName,
        );
        return i.reply({
          embeds: [new EmbedBuilder().setColor(0x57f287).setTitle("Vehicle Registered")
            .addFields(
              { name: "Plate", value: v.plate, inline: true },
              { name: "Model", value: v.model, inline: true },
              { name: "Color", value: `${v.color} (${v.color_type})`, inline: true },
              { name: "Insurance", value: v.insurance, inline: true },
              { name: "Registration", value: v.registration, inline: true },
            )],
          ephemeral: true,
        });
      }

      if (sub === "info") {
        const v = await getVehicle(i.options.getString("plate", true));
        if (!v) return i.reply({ content: "Vehicle not found.", ephemeral: true });
        return i.reply({
          embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle(`Vehicle — ${v.plate}`)
            .addFields(
              { name: "Model", value: v.model, inline: true },
              { name: "Color", value: `${v.color} (${v.color_type})`, inline: true },
              { name: "Insurance", value: v.insurance, inline: true },
              { name: "Registration", value: v.registration, inline: true },
              { name: "Impounded", value: v.is_impounded ? `Yes (Fee: ${v.impound_fee ?? "N/A"})` : "No", inline: true },
            )],
          ephemeral: true,
        });
      }

      if (sub === "edit") {
        const updated = await editVehicle(i.options.getString("plate", true), i.options.getString("field", true), i.options.getString("value", true));
        if (!updated) return i.reply({ content: "Vehicle not found.", ephemeral: true });
        return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`Vehicle **${updated.plate}** updated.`)], ephemeral: true });
      }

      if (sub === "delete") {
        const deleted = await deleteVehicle(i.user.id, i.guildId, i.options.getString("plate", true));
        if (!deleted) return i.reply({ content: "Vehicle not found or not yours.", ephemeral: true });
        return i.reply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("Vehicle deleted.")], ephemeral: true });
      }
      return;
    },
  },

  // ── HAND_ID ──────────────────────────────────────────────────────────────
  {
    data: new SlashCommandBuilder()
      .setName("hand-id")
      .setDescription("Show your character's ID to the channel")
      .addStringOption((o) => o.setName("name").setDescription("Character full name").setRequired(true))
      .addStringOption((o) =>
        o.setName("authenticity").setDescription("ID authenticity").setRequired(true)
          .addChoices({ name: "Authentic", value: "Authentic" }, { name: "Fake", value: "Fake" }),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return guildOnly(i);
      const name = i.options.getString("name", true);
      const auth = i.options.getString("authenticity", true);
      const civ = await getCivilian(i.user.id, i.guildId, name);
      if (!civ) return i.reply({ content: `No character named "${name}" found.`, ephemeral: true });
      const embed = new EmbedBuilder()
        .setColor(auth === "Authentic" ? 0x57f287 : 0xed4245)
        .setTitle(`🪪 Identification Card ${auth === "Fake" ? "*(Fake)*" : ""}`)
        .addFields(
          { name: "Name", value: `${civ.forename} ${civ.surname}`, inline: true },
          { name: "DOB", value: civ.date_of_birth, inline: true },
          { name: "Gender", value: civ.gender, inline: true },
          { name: "Hair Color", value: civ.hair_color, inline: true },
          { name: "Blood Type", value: civ.blood_type, inline: true },
          { name: "Occupation", value: civ.occupation, inline: true },
          { name: "Address", value: civ.address, inline: false },
        )
        .setFooter({ text: auth === "Fake" ? "⚠️ This ID appears to be FAKE" : "ID Verified" });
      return i.reply({ embeds: [embed] });
    },
  },
];
