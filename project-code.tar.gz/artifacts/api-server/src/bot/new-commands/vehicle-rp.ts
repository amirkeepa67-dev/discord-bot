import {
  SlashCommandBuilder,
  EmbedBuilder,
  type ChatInputCommandInteraction,
} from "discord.js";
import {
  getActiveCivilian,
  getOfficerStatus,
  updateOfficerStatus,
  getVehicleStatus,
  updateVehicleStatus,
} from "../character-db.js";

export const vehicleRpCommands = [
  {
    data: new SlashCommandBuilder()
      .setName("engine")
      .setDescription("Turn your vehicle engine on or off")
      .addStringOption((o) =>
        o.setName("state").setDescription("on or off").setRequired(true)
          .addChoices({ name: "On", value: "on" }, { name: "Off", value: "off" }),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const state = i.options.getString("state", true) === "on";
      const vs = await getVehicleStatus(i.user.id, i.guildId);
      if (vs.fuel_level <= 0 && state)
        return i.reply({ content: "Your vehicle is out of fuel! Use `/fuel` to check status.", ephemeral: true });
      await updateVehicleStatus(i.user.id, i.guildId, { engine_on: state });
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      const name = civ ? `${civ.forename} ${civ.surname}` : i.user.displayName;
      return i.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(state ? 0x57f287 : 0xed4245)
            .setDescription(`*${name} turns the engine **${state ? "on" : "off"}**.*`),
        ],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("fuel")
      .setDescription("Check your vehicle's fuel level"),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const vs = await getVehicleStatus(i.user.id, i.guildId);
      const fuel = vs.fuel_level;
      const bar = "█".repeat(Math.round(fuel / 10)) + "░".repeat(10 - Math.round(fuel / 10));
      const color = fuel > 50 ? 0x57f287 : fuel > 20 ? 0xfee75c : 0xed4245;
      return i.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle("Fuel Level")
            .setDescription(`\`${bar}\` **${fuel}%**\n${fuel <= 0 ? "⛽ Vehicle is out of fuel!" : fuel <= 20 ? "⚠️ Low fuel!" : ""}`)
            .addFields(
              { name: "Engine", value: vs.engine_on ? "🟢 On" : "🔴 Off", inline: true },
              { name: "Locked", value: vs.is_locked ? "🔒 Yes" : "🔓 No", inline: true },
            ),
        ],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("grab")
      .setDescription("Grab someone (RP action)")
      .addUserOption((o) => o.setName("target").setDescription("Person to grab").setRequired(true)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const target = i.options.getUser("target", true);
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      const name = civ ? `${civ.forename} ${civ.surname}` : i.user.displayName;
      const targetCiv = await getActiveCivilian(target.id, i.guildId);
      const targetName = targetCiv ? `${targetCiv.forename} ${targetCiv.surname}` : target.displayName;
      return i.reply({
        embeds: [new EmbedBuilder().setColor(0xfee75c).setDescription(`*${name} grabs ${targetName}.*`)],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("hotwire")
      .setDescription("Attempt to hotwire a vehicle"),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      const name = civ ? `${civ.forename} ${civ.surname}` : i.user.displayName;
      const success = Math.random() < 0.6;
      if (success) {
        await updateVehicleStatus(i.user.id, i.guildId, { engine_on: true });
      }
      return i.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(success ? 0x57f287 : 0xed4245)
            .setDescription(
              success
                ? `*${name} successfully hotwires the vehicle. The engine roars to life.*`
                : `*${name} fumbles with the wires... the attempt fails.*`,
            ),
        ],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("lock-vehicle")
      .setDescription("Lock or unlock your vehicle"),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const vs = await getVehicleStatus(i.user.id, i.guildId);
      const newLock = !vs.is_locked;
      await updateVehicleStatus(i.user.id, i.guildId, { is_locked: newLock });
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      const name = civ ? `${civ.forename} ${civ.surname}` : i.user.displayName;
      return i.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(newLock ? 0x5865f2 : 0x57f287)
            .setDescription(`*${name} ${newLock ? "locks" : "unlocks"} the vehicle.*`),
        ],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("lockpick")
      .setDescription("Attempt to lockpick a vehicle"),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      const name = civ ? `${civ.forename} ${civ.surname}` : i.user.displayName;
      const success = Math.random() < 0.4;
      if (success) {
        await updateVehicleStatus(i.user.id, i.guildId, { is_locked: false });
      }
      return i.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(success ? 0x57f287 : 0xed4245)
            .setDescription(
              success
                ? `*${name} carefully works the lock... **click** — the door opens.*`
                : `*${name} tries to lockpick the vehicle but can't crack it.*`,
            ),
        ],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("me")
      .setDescription("Perform a roleplay action as your character")
      .addStringOption((o) =>
        o.setName("action").setDescription("What your character does").setRequired(true),
      ),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const action = i.options.getString("action", true);
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      const name = civ ? `${civ.forename} ${civ.surname}` : i.user.displayName;
      return i.reply({
        embeds: [new EmbedBuilder().setColor(0x5865f2).setDescription(`*${name} ${action}*`)],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("on-duty")
      .setDescription("Set yourself as on duty"),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      await updateOfficerStatus(i.user.id, i.guildId, "on_duty", true);
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      const name = civ ? `${civ.forename} ${civ.surname}` : i.user.displayName;
      return i.reply({
        embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`**${name}** is now **on duty**. 🟢`)],
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("off-duty")
      .setDescription("Set yourself as off duty"),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      await updateOfficerStatus(i.user.id, i.guildId, "on_duty", false);
      await updateOfficerStatus(i.user.id, i.guildId, "bodycam_active", false);
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      const name = civ ? `${civ.forename} ${civ.surname}` : i.user.displayName;
      return i.reply({
        embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`**${name}** is now **off duty**. 🔴`)],
      });
    },
  },
];
