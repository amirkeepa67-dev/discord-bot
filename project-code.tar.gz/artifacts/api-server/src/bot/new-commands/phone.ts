import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  type ChatInputCommandInteraction,
  type ButtonInteraction,
  type ModalSubmitInteraction,
} from "discord.js";
import { pool } from "@workspace/db";
import { getActiveCivilian } from "../character-db.js";
import { getOrCreateWallet, transferCash, getConfig, fmt } from "../economy-db.js";
import { getItemByName } from "../db.js";

const GTA_MAP_URL =
  "https://www.gtaweb.eu/gtao-map/assets/map.jpg";

function phoneHomeEmbed(civName: string, phoneNumber: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0x23272a)
    .setTitle("📱 Phone")
    .setDescription(`**${civName}**\n📞 ${phoneNumber}`)
    .setFooter({ text: "Select an app below" });
}

function phoneHomeRow(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("phone:twitter").setLabel("Twitter/X").setEmoji("🐦").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("phone:instagram").setLabel("Instagram").setEmoji("📷").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("phone:messages").setLabel("Messages").setEmoji("💬").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("phone:cashapp").setLabel("CashApp").setEmoji("💸").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("phone:maps").setLabel("Maps").setEmoji("🗺️").setStyle(ButtonStyle.Secondary),
  );
}

function phoneHomeRow2(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("phone:blackmarket").setLabel("Black Market").setEmoji("🖤").setStyle(ButtonStyle.Danger),
  );
}

export const phoneCommands = [
  {
    data: new SlashCommandBuilder()
      .setName("phone")
      .setDescription("Open your phone"),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      if (!civ || !civ.phone_number) {
        return i.reply({ content: "You need an active character with a phone number. Create one with `/civilian create`.", ephemeral: true });
      }
      return i.reply({
        embeds: [phoneHomeEmbed(`${civ.forename} ${civ.surname}`, civ.phone_number)],
        components: [phoneHomeRow(), phoneHomeRow2()],
        ephemeral: true,
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("tweet")
      .setDescription("Post a tweet")
      .addStringOption((o) => o.setName("content").setDescription("Tweet content (max 280 chars)").setRequired(true).setMaxLength(280)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      const handle = civ ? `@${civ.forename}${civ.surname}`.replace(/\s/g, "").toLowerCase() : `@${i.user.username}`;
      const content = i.options.getString("content", true);
      const res = await pool.query<{ id: number }>(
        `INSERT INTO twitter_posts (user_id, guild_id, handle, content) VALUES ($1,$2,$3,$4) RETURNING id`,
        [i.user.id, i.guildId, handle, content],
      );
      const postId = res.rows[0]!.id;
      const embed = new EmbedBuilder()
        .setColor(0x1da1f2)
        .setAuthor({ name: handle, iconURL: i.user.displayAvatarURL() })
        .setDescription(content)
        .setFooter({ text: `Tweet #${postId} • 0 likes` });
      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId(`tw:like:${postId}`).setLabel("Like").setEmoji("❤️").setStyle(ButtonStyle.Danger),
      );
      return i.reply({ embeds: [embed], components: [row] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("instagram")
      .setDescription("Post to Instagram")
      .addStringOption((o) => o.setName("caption").setDescription("Caption").setRequired(true).setMaxLength(300))
      .addStringOption((o) => o.setName("image_url").setDescription("Image URL (optional)")),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const civ = await getActiveCivilian(i.user.id, i.guildId);
      const handle = civ ? `@${civ.forename}${civ.surname}`.replace(/\s/g, "").toLowerCase() : `@${i.user.username}`;
      const caption = i.options.getString("caption", true);
      const imageUrl = i.options.getString("image_url");
      const res = await pool.query<{ id: number }>(
        `INSERT INTO instagram_posts (user_id, guild_id, handle, caption, image_url) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
        [i.user.id, i.guildId, handle, caption, imageUrl ?? null],
      );
      const postId = res.rows[0]!.id;
      const embed = new EmbedBuilder()
        .setColor(0xe1306c)
        .setAuthor({ name: handle, iconURL: i.user.displayAvatarURL() })
        .setDescription(caption)
        .setFooter({ text: `Post #${postId} • 0 likes` });
      if (imageUrl) embed.setImage(imageUrl);
      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId(`ig:like:${postId}`).setLabel("Like").setEmoji("❤️").setStyle(ButtonStyle.Danger),
      );
      return i.reply({ embeds: [embed], components: [row] });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("message")
      .setDescription("Send a phone message to another character")
      .addUserOption((o) => o.setName("to").setDescription("Recipient").setRequired(true))
      .addStringOption((o) => o.setName("content").setDescription("Message").setRequired(true).setMaxLength(500)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const recipient = i.options.getUser("to", true);
      if (recipient.id === i.user.id) return i.reply({ content: "You can't message yourself.", ephemeral: true });
      if (recipient.bot) return i.reply({ content: "Can't message bots.", ephemeral: true });
      const content = i.options.getString("content", true);
      const senderCiv = await getActiveCivilian(i.user.id, i.guildId);
      const senderName = senderCiv ? `${senderCiv.forename} ${senderCiv.surname}` : i.user.displayName;
      const senderPhone = senderCiv?.phone_number ?? "Unknown";
      await pool.query(
        `INSERT INTO phone_messages (sender_id, receiver_id, guild_id, content) VALUES ($1,$2,$3,$4)`,
        [i.user.id, recipient.id, i.guildId, content],
      );
      const embed = new EmbedBuilder()
        .setColor(0x57f287)
        .setTitle("New Message Received")
        .setDescription(`> ${content}`)
        .addFields({ name: "From", value: `${senderName} (${senderPhone})`, inline: true })
        .setFooter({ text: "Reply with /message" });
      await recipient.send({ embeds: [embed] }).catch(() => null);
      return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`Message sent to ${recipient}.`)], ephemeral: true });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("messages")
      .setDescription("View your recent messages"),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const res = await pool.query(
        `SELECT * FROM phone_messages WHERE receiver_id=$1 AND guild_id=$2 ORDER BY sent_at DESC LIMIT 10`,
        [i.user.id, i.guildId],
      );
      if (!res.rows.length) return i.reply({ content: "No messages.", ephemeral: true });
      const embed = new EmbedBuilder().setColor(0x57f287).setTitle("📨 Messages");
      for (const msg of res.rows) {
        const senderCiv = await getActiveCivilian(msg.sender_id, i.guildId);
        const senderName = senderCiv ? `${senderCiv.forename} ${senderCiv.surname}` : `<@${msg.sender_id}>`;
        embed.addFields({ name: senderName, value: msg.content.substring(0, 100) });
      }
      await pool.query(`UPDATE phone_messages SET is_read=true WHERE receiver_id=$1 AND guild_id=$2`, [i.user.id, i.guildId]);
      return i.reply({ embeds: [embed], ephemeral: true });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("cashapp")
      .setDescription("Send money via CashApp")
      .addUserOption((o) => o.setName("to").setDescription("Recipient").setRequired(true))
      .addNumberOption((o) => o.setName("amount").setDescription("Amount to send").setRequired(true).setMinValue(0.01)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const recipient = i.options.getUser("to", true);
      const amount = i.options.getNumber("amount", true);
      if (recipient.id === i.user.id) return i.reply({ content: "Can't send to yourself.", ephemeral: true });
      const config = await getConfig(i.guildId);
      const result = await transferCash(i.guildId, i.user.id, recipient.id, amount);
      if (!result.success) return i.reply({ content: result.reason ?? "Transfer failed.", ephemeral: true });
      return i.reply({
        embeds: [new EmbedBuilder().setColor(0x00d632).setTitle("💸 CashApp").setDescription(`Sent **${fmt(config, amount)}** to ${recipient}.`)],
        ephemeral: true,
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("maps")
      .setDescription("Open the city map"),
    async execute(i: ChatInputCommandInteraction) {
      return i.reply({
        embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle("🗺️ Los Santos Map").setImage(GTA_MAP_URL)],
        ephemeral: true,
      });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("blackmarket")
      .setDescription("Browse the black market")
      .addIntegerOption((o) => o.setName("page").setDescription("Page").setMinValue(1)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const page = Math.max(1, i.options.getInteger("page") ?? 1);
      const perPage = 5;
      const count = await pool.query<{ count: string }>(
        `SELECT COUNT(*) AS count FROM blackmarket_listings WHERE guild_id=$1 AND is_active=true`,
        [i.guildId],
      );
      const total = parseInt(count.rows[0]?.count ?? "0", 10);
      const totalPages = Math.max(1, Math.ceil(total / perPage));
      const cur = Math.min(page, totalPages);
      const listings = await pool.query(
        `SELECT bl.*, items.name AS item_name FROM blackmarket_listings bl JOIN items ON bl.item_id=items.id WHERE bl.guild_id=$1 AND bl.is_active=true LIMIT $2 OFFSET $3`,
        [i.guildId, perPage, (cur - 1) * perPage],
      );
      const config = await getConfig(i.guildId);
      const embed = new EmbedBuilder()
        .setColor(0x2b2d31)
        .setTitle("🖤 Black Market")
        .setFooter({ text: `Page ${cur} of ${totalPages}` });
      if (!listings.rows.length) {
        embed.setDescription("Nothing listed right now.");
        return i.reply({ embeds: [embed], ephemeral: true });
      }
      const rows: ActionRowBuilder<ButtonBuilder>[] = [];
      for (const l of listings.rows) {
        embed.addFields({ name: `${l.item_name} × ${l.quantity}`, value: `Asking: ${fmt(config, l.price)} | Seller: <@${l.seller_id}>`, inline: false });
        rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setCustomId(`bm:buy:${l.id}`).setLabel(`Buy ${l.item_name}`).setStyle(ButtonStyle.Danger),
        ));
      }
      return i.reply({ embeds: [embed], components: rows.slice(0, 5), ephemeral: true });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName("bm-list")
      .setDescription("List an item on the black market")
      .addStringOption((o) => o.setName("item_name").setDescription("Item to list").setRequired(true).setAutocomplete(true))
      .addIntegerOption((o) => o.setName("quantity").setDescription("Quantity").setRequired(true).setMinValue(1))
      .addNumberOption((o) => o.setName("price").setDescription("Asking price").setRequired(true).setMinValue(0.01)),
    async execute(i: ChatInputCommandInteraction) {
      if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
      const itemName = i.options.getString("item_name", true);
      const qty = i.options.getInteger("quantity", true);
      const price = i.options.getNumber("price", true);
      const { getItemByName: gib, getUserItemEntry, removeFromInventory } = await import("../db.js");
      const item = await gib(itemName);
      if (!item) return i.reply({ content: "Item not found.", ephemeral: true });
      const entry = await getUserItemEntry(i.user.id, item.id);
      if (!entry || entry.quantity < qty) return i.reply({ content: `You don't have ${qty}x **${item.name}** in your inventory.`, ephemeral: true });
      await removeFromInventory(i.user.id, item.id, qty);
      const config = await getConfig(i.guildId);
      await pool.query(
        `INSERT INTO blackmarket_listings (seller_id, guild_id, item_id, quantity, price) VALUES ($1,$2,$3,$4,$5)`,
        [i.user.id, i.guildId, item.id, qty, price],
      );
      return i.reply({ embeds: [new EmbedBuilder().setColor(0x2b2d31).setDescription(`Listed **${qty}x ${item.name}** on the black market for ${fmt(config, price)}.`)], ephemeral: true });
    },
  },
];

export async function handlePhoneButton(i: ButtonInteraction, action: string) {
  if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
  if (action === "twitter") {
    const posts = await pool.query(
      `SELECT * FROM twitter_posts WHERE guild_id=$1 ORDER BY posted_at DESC LIMIT 5`,
      [i.guildId],
    );
    const embed = new EmbedBuilder().setColor(0x1da1f2).setTitle("🐦 Twitter/X Feed");
    if (!posts.rows.length) embed.setDescription("No tweets yet. Use `/tweet` to post.");
    for (const p of posts.rows) embed.addFields({ name: `${p.handle}`, value: `${p.content}\n❤️ ${p.likes} likes` });
    return i.reply({ embeds: [embed], ephemeral: true });
  }
  if (action === "instagram") {
    const posts = await pool.query(
      `SELECT * FROM instagram_posts WHERE guild_id=$1 ORDER BY posted_at DESC LIMIT 5`,
      [i.guildId],
    );
    const embed = new EmbedBuilder().setColor(0xe1306c).setTitle("📷 Instagram Feed");
    if (!posts.rows.length) embed.setDescription("No posts yet. Use `/instagram` to post.");
    for (const p of posts.rows) embed.addFields({ name: p.handle, value: `${p.caption}\n❤️ ${p.likes} likes` });
    return i.reply({ embeds: [embed], ephemeral: true });
  }
  if (action === "messages") {
    const msgs = await pool.query(
      `SELECT * FROM phone_messages WHERE receiver_id=$1 AND guild_id=$2 ORDER BY sent_at DESC LIMIT 5`,
      [i.user.id, i.guildId],
    );
    const embed = new EmbedBuilder().setColor(0x57f287).setTitle("💬 Messages");
    if (!msgs.rows.length) embed.setDescription("No messages. Use `/message` to send one.");
    for (const m of msgs.rows) embed.addFields({ name: `From <@${m.sender_id}>`, value: m.content.substring(0, 100) });
    return i.reply({ embeds: [embed], ephemeral: true });
  }
  if (action === "cashapp") {
    const wallet = await getOrCreateWallet(i.guildId, i.user.id);
    const config = await getConfig(i.guildId);
    return i.reply({ embeds: [new EmbedBuilder().setColor(0x00d632).setTitle("💸 CashApp").setDescription(`Balance: **${fmt(config, wallet.cash)}**\n\nUse \`/cashapp\` to send money.`)], ephemeral: true });
  }
  if (action === "maps") {
    return i.reply({ embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle("🗺️ Los Santos").setImage(GTA_MAP_URL)], ephemeral: true });
  }
  if (action === "blackmarket") {
    const listings = await pool.query(
      `SELECT bl.*, items.name AS item_name FROM blackmarket_listings bl JOIN items ON bl.item_id=items.id WHERE bl.guild_id=$1 AND bl.is_active=true LIMIT 5`,
      [i.guildId],
    );
    const config = await getConfig(i.guildId);
    const embed = new EmbedBuilder().setColor(0x2b2d31).setTitle("🖤 Black Market");
    if (!listings.rows.length) { embed.setDescription("Nothing available right now."); return i.reply({ embeds: [embed], ephemeral: true }); }
    const rows: ActionRowBuilder<ButtonBuilder>[] = [];
    for (const l of listings.rows) {
      embed.addFields({ name: `${l.item_name} × ${l.quantity}`, value: `${fmt(config, l.price)}`, inline: true });
      rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId(`bm:buy:${l.id}`).setLabel(`Buy ${l.item_name}`).setStyle(ButtonStyle.Danger)));
    }
    return i.reply({ embeds: [embed], components: rows.slice(0, 5), ephemeral: true });
  }
  return;
}

export async function handleSocialLike(i: ButtonInteraction, type: "tw" | "ig", postId: string) {
  const table = type === "tw" ? "twitter_posts" : "instagram_posts";
  const res = await pool.query<{ id: number; likes: number }>(`UPDATE ${table} SET likes=likes+1 WHERE id=$1 RETURNING id, likes`, [parseInt(postId, 10)]);
  if (!res.rows.length) return i.reply({ content: "Post not found.", ephemeral: true });
  const likes = res.rows[0]!.likes;
  const newEmbed = EmbedBuilder.from(i.message.embeds[0]!).setFooter({ text: i.message.embeds[0]!.footer?.text?.replace(/\d+ likes/, `${likes} likes`) ?? `${likes} likes` });
  return i.update({ embeds: [newEmbed] });
}

export async function handleBmBuy(i: ButtonInteraction, listingId: string) {
  if (!i.guildId) return i.reply({ content: "Server only.", ephemeral: true });
  const id = parseInt(listingId, 10);
  const res = await pool.query(
    `SELECT bl.*, items.name AS item_name FROM blackmarket_listings bl JOIN items ON bl.item_id=items.id WHERE bl.id=$1 AND bl.is_active=true`,
    [id],
  );
  const listing = res.rows[0];
  if (!listing) return i.reply({ content: "This listing is no longer available.", ephemeral: true });
  if (listing.seller_id === i.user.id) return i.reply({ content: "You can't buy your own listing.", ephemeral: true });
  const config = await getConfig(i.guildId);
  const wallet = await getOrCreateWallet(i.guildId, i.user.id);
  if (parseFloat(wallet.cash) < parseFloat(listing.price)) return i.reply({ content: `You need **${fmt(config, listing.price)}** cash to buy this.`, ephemeral: true });
  const result = await transferCash(i.guildId, i.user.id, listing.seller_id, parseFloat(listing.price));
  if (!result.success) return i.reply({ content: result.reason ?? "Purchase failed.", ephemeral: true });
  const { addToInventory } = await import("../db.js");
  await addToInventory(i.user.id, listing.item_id, listing.quantity);
  await pool.query(`UPDATE blackmarket_listings SET is_active=false WHERE id=$1`, [id]);
  return i.reply({ embeds: [new EmbedBuilder().setColor(0x57f287).setDescription(`Purchased **${listing.quantity}x ${listing.item_name}** for ${fmt(config, listing.price)}!`)], ephemeral: true });
}
