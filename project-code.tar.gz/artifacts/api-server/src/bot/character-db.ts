import { pool } from "@workspace/db";

export interface Civilian {
  id: number;
  user_id: string;
  guild_id: string;
  forename: string;
  surname: string;
  date_of_birth: string;
  gender: string;
  hair_color: string;
  blood_type: string;
  height: string;
  weight: string;
  address: string;
  occupation: string;
  phone_number: string | null;
  is_active: boolean;
  created_at: Date;
}

export interface Firearm {
  id: number;
  civilian_id: number;
  serial_number: string;
  model: string;
  color: string;
  name: string;
}

export interface Vehicle {
  id: number;
  civilian_id: number;
  plate: string;
  model: string;
  color: string;
  color_type: string;
  insurance: string;
  registration: string;
  name: string;
  is_impounded: boolean;
  impound_fee: string | null;
}

export interface OfficerStatus {
  user_id: string;
  guild_id: string;
  bodycam_active: boolean;
  on_duty: boolean;
}

export interface VehicleStatus {
  engine_on: boolean;
  fuel_level: number;
  is_locked: boolean;
}

async function generatePhoneNumber(guildId: string): Promise<string> {
  while (true) {
    const area = Math.floor(Math.random() * 900) + 100;
    const line = Math.floor(Math.random() * 9000) + 1000;
    const number = `(${area}) 555-${line}`;
    const exists = await pool.query(
      `SELECT 1 FROM civilians WHERE phone_number = $1 AND guild_id = $2`,
      [number, guildId],
    );
    if ((exists.rowCount ?? 0) === 0) return number;
  }
}

export async function createCivilian(
  userId: string,
  guildId: string,
  data: Omit<Civilian, "id" | "user_id" | "guild_id" | "phone_number" | "is_active" | "created_at">,
): Promise<Civilian> {
  const phone = await generatePhoneNumber(guildId);
  const res = await pool.query<Civilian>(
    `INSERT INTO civilians (user_id, guild_id, forename, surname, date_of_birth, gender, hair_color, blood_type, height, weight, address, occupation, phone_number)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
    [
      userId, guildId, data.forename, data.surname, data.date_of_birth,
      data.gender, data.hair_color, data.blood_type, data.height,
      data.weight, data.address, data.occupation, phone,
    ],
  );
  return res.rows[0]!;
}

export async function getCivilian(
  userId: string,
  guildId: string,
  name: string,
): Promise<Civilian | null> {
  const res = await pool.query<Civilian>(
    `SELECT * FROM civilians WHERE user_id=$1 AND guild_id=$2 AND LOWER(forename||' '||surname)=LOWER($3)`,
    [userId, guildId, name],
  );
  return res.rows[0] ?? null;
}

export async function getCivilianById(id: number): Promise<Civilian | null> {
  const res = await pool.query<Civilian>(`SELECT * FROM civilians WHERE id=$1`, [id]);
  return res.rows[0] ?? null;
}

export async function getCivilianByName(
  guildId: string,
  name: string,
): Promise<Civilian | null> {
  const res = await pool.query<Civilian>(
    `SELECT * FROM civilians WHERE guild_id=$1 AND LOWER(forename||' '||surname)=LOWER($2)`,
    [guildId, name],
  );
  return res.rows[0] ?? null;
}

export async function getActiveCivilian(
  userId: string,
  guildId: string,
): Promise<Civilian | null> {
  const res = await pool.query<Civilian>(
    `SELECT * FROM civilians WHERE user_id=$1 AND guild_id=$2 AND is_active=true LIMIT 1`,
    [userId, guildId],
  );
  return res.rows[0] ?? null;
}

export async function listCivilians(
  userId: string,
  guildId: string,
): Promise<Civilian[]> {
  const res = await pool.query<Civilian>(
    `SELECT * FROM civilians WHERE user_id=$1 AND guild_id=$2 ORDER BY forename`,
    [userId, guildId],
  );
  return res.rows;
}

export async function setActiveCivilian(
  userId: string,
  guildId: string,
  civilianId: number,
): Promise<void> {
  await pool.query(
    `UPDATE civilians SET is_active=false WHERE user_id=$1 AND guild_id=$2`,
    [userId, guildId],
  );
  await pool.query(`UPDATE civilians SET is_active=true WHERE id=$1`, [civilianId]);
}

export async function editCivilian(
  civilianId: number,
  field: string,
  value: string,
): Promise<Civilian | null> {
  const allowed = [
    "forename","surname","date_of_birth","gender","hair_color",
    "blood_type","height","weight","address","occupation",
  ];
  if (!allowed.includes(field)) throw new Error("Invalid field");
  const res = await pool.query<Civilian>(
    `UPDATE civilians SET ${field}=$1 WHERE id=$2 RETURNING *`,
    [value, civilianId],
  );
  return res.rows[0] ?? null;
}

export async function deleteCivilian(
  userId: string,
  guildId: string,
  name: string,
): Promise<boolean> {
  const res = await pool.query(
    `DELETE FROM civilians WHERE user_id=$1 AND guild_id=$2 AND LOWER(forename||' '||surname)=LOWER($3)`,
    [userId, guildId, name],
  );
  return (res.rowCount ?? 0) > 0;
}

export async function registerFirearm(
  civilianId: number,
  model: string,
  color: string,
  name: string,
): Promise<Firearm> {
  const serial = `SN-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2,6).toUpperCase()}`;
  const res = await pool.query<Firearm>(
    `INSERT INTO firearms (civilian_id, serial_number, model, color, name) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [civilianId, serial, model, color, name],
  );
  return res.rows[0]!;
}

export async function getFirearm(serialNumber: string): Promise<Firearm | null> {
  const res = await pool.query<Firearm>(
    `SELECT * FROM firearms WHERE LOWER(serial_number)=LOWER($1)`,
    [serialNumber],
  );
  return res.rows[0] ?? null;
}

export async function editFirearm(
  serialNumber: string,
  field: string,
  value: string,
): Promise<Firearm | null> {
  const allowed = ["model","color","name"];
  if (!allowed.includes(field)) throw new Error("Invalid field");
  const res = await pool.query<Firearm>(
    `UPDATE firearms SET ${field}=$1 WHERE LOWER(serial_number)=LOWER($2) RETURNING *`,
    [value, serialNumber],
  );
  return res.rows[0] ?? null;
}

export async function deleteFirearm(
  userId: string,
  guildId: string,
  serialNumber: string,
): Promise<boolean> {
  const res = await pool.query(
    `DELETE FROM firearms f
     USING civilians c
     WHERE f.civilian_id=c.id AND c.user_id=$1 AND c.guild_id=$2 AND LOWER(f.serial_number)=LOWER($3)`,
    [userId, guildId, serialNumber],
  );
  return (res.rowCount ?? 0) > 0;
}

export async function registerVehicle(
  civilianId: number,
  plate: string,
  model: string,
  color: string,
  colorType: string,
  insurance: string,
  registration: string,
  name: string,
): Promise<Vehicle> {
  const res = await pool.query<Vehicle>(
    `INSERT INTO vehicles (civilian_id,plate,model,color,color_type,insurance,registration,name)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [civilianId, plate.toUpperCase(), model, color, colorType, insurance, registration, name],
  );
  return res.rows[0]!;
}

export async function getVehicle(plate: string): Promise<Vehicle | null> {
  const res = await pool.query<Vehicle>(
    `SELECT * FROM vehicles WHERE UPPER(plate)=UPPER($1)`,
    [plate],
  );
  return res.rows[0] ?? null;
}

export async function editVehicle(
  plate: string,
  field: string,
  value: string,
): Promise<Vehicle | null> {
  const allowed = ["plate","model","color","color_type","insurance","registration","name"];
  if (!allowed.includes(field)) throw new Error("Invalid field");
  const res = await pool.query<Vehicle>(
    `UPDATE vehicles SET ${field}=$1 WHERE UPPER(plate)=UPPER($2) RETURNING *`,
    [value, plate],
  );
  return res.rows[0] ?? null;
}

export async function deleteVehicle(
  userId: string,
  guildId: string,
  plate: string,
): Promise<boolean> {
  const res = await pool.query(
    `DELETE FROM vehicles v
     USING civilians c
     WHERE v.civilian_id=c.id AND c.user_id=$1 AND c.guild_id=$2 AND UPPER(v.plate)=UPPER($3)`,
    [userId, guildId, plate],
  );
  return (res.rowCount ?? 0) > 0;
}

export async function setVehicleImpound(
  plate: string,
  impounded: boolean,
  fee?: number,
): Promise<boolean> {
  const res = await pool.query(
    `UPDATE vehicles SET is_impounded=$1, impound_fee=$2 WHERE UPPER(plate)=UPPER($3)`,
    [impounded, fee ?? null, plate],
  );
  return (res.rowCount ?? 0) > 0;
}

export async function addFlag(civilianId: number, flagType: string): Promise<void> {
  await pool.query(
    `INSERT INTO civilian_flags (civilian_id, flag_type) VALUES ($1,$2)`,
    [civilianId, flagType],
  );
}

export async function removeFlag(civilianId: number, flagType: string): Promise<boolean> {
  const res = await pool.query(
    `DELETE FROM civilian_flags WHERE civilian_id=$1 AND LOWER(flag_type)=LOWER($2)`,
    [civilianId, flagType],
  );
  return (res.rowCount ?? 0) > 0;
}

export async function getFlags(civilianId: number): Promise<string[]> {
  const res = await pool.query<{ flag_type: string }>(
    `SELECT flag_type FROM civilian_flags WHERE civilian_id=$1`,
    [civilianId],
  );
  return res.rows.map((r) => r.flag_type);
}

export async function issueBolo(
  guildId: string,
  civilianName: string,
  reason: string,
  issuedBy: string,
): Promise<number> {
  const res = await pool.query<{ id: number }>(
    `INSERT INTO bolos (guild_id, civilian_name, reason, issued_by) VALUES ($1,$2,$3,$4) RETURNING id`,
    [guildId, civilianName, reason, issuedBy],
  );
  return res.rows[0]!.id;
}

export async function clearBolo(guildId: string, civilianName: string): Promise<boolean> {
  const res = await pool.query(
    `UPDATE bolos SET is_active=false WHERE guild_id=$1 AND LOWER(civilian_name)=LOWER($2) AND is_active=true`,
    [guildId, civilianName],
  );
  return (res.rowCount ?? 0) > 0;
}

export async function checkBolo(guildId: string, civilianName: string) {
  const res = await pool.query(
    `SELECT * FROM bolos WHERE guild_id=$1 AND LOWER(civilian_name)=LOWER($2) AND is_active=true`,
    [guildId, civilianName],
  );
  return res.rows[0] ?? null;
}

export async function addCase(
  guildId: string,
  caseType: string,
  civilianName: string,
  officerId: string,
  charges?: string,
  cost?: number,
  notes?: string,
): Promise<number> {
  const res = await pool.query<{ id: number }>(
    `INSERT INTO law_cases (guild_id, case_type, civilian_name, officer_id, charges, cost, notes)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [guildId, caseType, civilianName, officerId, charges ?? null, cost ?? null, notes ?? null],
  );
  return res.rows[0]!.id;
}

export async function lookupCase(guildId: string, caseId: number, caseType?: string) {
  let q = `SELECT * FROM law_cases WHERE guild_id=$1 AND id=$2`;
  const params: (string | number)[] = [guildId, caseId];
  if (caseType) { q += ` AND case_type=$3`; params.push(caseType); }
  const res = await pool.query(q, params);
  return res.rows[0] ?? null;
}

export async function getEvidence(guildId: string, targetUserId: string) {
  const res = await pool.query(
    `SELECT * FROM evidence WHERE guild_id=$1 AND target_user_id=$2 ORDER BY confiscated_at DESC`,
    [guildId, targetUserId],
  );
  return res.rows;
}

export async function addEvidence(
  guildId: string,
  targetUserId: string,
  itemName: string,
  quantity: number,
  confiscatedBy: string,
): Promise<void> {
  await pool.query(
    `INSERT INTO evidence (target_user_id, guild_id, item_name, quantity, confiscated_by)
     VALUES ($1,$2,$3,$4,$5)`,
    [targetUserId, guildId, itemName, quantity, confiscatedBy],
  );
}

export async function getOfficerStatus(
  userId: string,
  guildId: string,
): Promise<OfficerStatus> {
  await pool.query(
    `INSERT INTO officer_status (user_id, guild_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`,
    [userId, guildId],
  );
  const res = await pool.query<OfficerStatus>(
    `SELECT * FROM officer_status WHERE user_id=$1 AND guild_id=$2`,
    [userId, guildId],
  );
  return res.rows[0]!;
}

export async function updateOfficerStatus(
  userId: string,
  guildId: string,
  field: "bodycam_active" | "on_duty",
  value: boolean,
): Promise<void> {
  await pool.query(
    `INSERT INTO officer_status (user_id, guild_id, ${field}) VALUES ($1,$2,$3)
     ON CONFLICT (user_id, guild_id) DO UPDATE SET ${field}=$3`,
    [userId, guildId, value],
  );
}

export async function getVehicleStatus(
  userId: string,
  guildId: string,
): Promise<VehicleStatus> {
  await pool.query(
    `INSERT INTO vehicle_status (user_id, guild_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`,
    [userId, guildId],
  );
  const res = await pool.query<VehicleStatus>(
    `SELECT engine_on, fuel_level, is_locked FROM vehicle_status WHERE user_id=$1 AND guild_id=$2`,
    [userId, guildId],
  );
  return res.rows[0]!;
}

export async function updateVehicleStatus(
  userId: string,
  guildId: string,
  update: Partial<VehicleStatus>,
): Promise<void> {
  const fields = Object.keys(update) as (keyof VehicleStatus)[];
  if (fields.length === 0) return;
  const sets = fields.map((f, i) => `${f}=$${i + 3}`).join(", ");
  await pool.query(
    `INSERT INTO vehicle_status (user_id, guild_id) VALUES ($1,$2) ON CONFLICT (user_id, guild_id) DO UPDATE SET ${sets}`,
    [userId, guildId, ...fields.map((f) => update[f])],
  );
}
