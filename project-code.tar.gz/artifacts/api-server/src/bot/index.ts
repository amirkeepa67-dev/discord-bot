import {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  Collection,
  type ChatInputCommandInteraction,
  type StringSelectMenuInteraction,
  type ButtonInteraction,
} from "discord.js";
import { logger } from "../lib/logger.js";
import { commands, handleAutocomplete, handleStoreBuy, handleInvUse } from "./commands.js";
import { makeEconomyCommands } from "./new-commands/economy.js";
import { vehicleRpCommands } from "./new-commands/vehicle-rp.js";
import { casinoCommands, bjGames, handleBjButton } from "./new-commands/casino.js";
import { characterCommands } from "./new-commands/character.js";
import { policeCommands } from "./new-commands/police.js";
import { phoneCommands, handlePhoneButton, handleSocialLike, handleBmBuy } from "./new-commands/phone.js";

type AnyCommand = { data: { name: string; toJSON(): unknown }; execute(i: ChatInputCommandInteraction): Promise<unknown> };

export function startBot(): void {
  const token = process.env.DISCORD_TOKEN;
  const rawClientId = process.env.DISCORD_CLIENT_ID;

  if (!token || !rawClientId) {
    logger.warn("DISCORD_TOKEN or DISCORD_CLIENT_ID not set — bot will not start");
    return;
  }

  const clientIdMatch = rawClientId.match(/client_id=(\d+)/) ?? rawClientId.match(/^(\d+)$/);
  const clientId = clientIdMatch?.[1] ?? rawClientId;
  logger.info({ clientId }, "Using Discord client ID");

  const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
  });

  const economyCommands = makeEconomyCommands(client);

  const allCommands: AnyCommand[] = [
    ...commands,
    ...economyCommands,
    ...vehicleRpCommands,
    ...casinoCommands,
    ...characterCommands,
    ...policeCommands,
    ...phoneCommands,
  ] as AnyCommand[];

  const commandMap = new Collection<string, AnyCommand>();
  for (const cmd of allCommands) {
    commandMap.set(cmd.data.name, cmd);
  }

  const rest = new REST().setToken(token);

  client.once("ready", async () => {
    logger.info({ tag: client.user?.tag }, "Discord bot ready");
    try {
      await rest.put(Routes.applicationCommands(clientId), {
        body: allCommands.map((c) => c.data.toJSON()),
      });
      logger.info(`Registered ${allCommands.length} slash commands globally`);
    } catch (err) {
      logger.error({ err }, "Failed to register slash commands");
    }
  });

  client.on("interactionCreate", async (interaction) => {
    // ── Autocomplete ────────────────────────────────────────────────────────
    if (interaction.isAutocomplete()) {
      try { await handleAutocomplete(interaction); } catch (err) { logger.error({ err }, "Autocomplete error"); }
      return;
    }

    // ── String Select Menus ─────────────────────────────────────────────────
    if (interaction.isStringSelectMenu()) {
      const sel = interaction as StringSelectMenuInteraction;
      try {
        if (sel.customId === "store:buy") { await handleStoreBuy(sel); return; }
        if (sel.customId === "inv:use") { await handleInvUse(sel); return; }
      } catch (err) {
        logger.error({ err, customId: sel.customId }, "Select menu error");
        const msg = { content: "Something went wrong.", ephemeral: true };
        if (sel.replied || sel.deferred) await sel.followUp(msg).catch(() => undefined);
        else await sel.reply(msg).catch(() => undefined);
      }
      return;
    }

    // ── Buttons ─────────────────────────────────────────────────────────────
    if (interaction.isButton()) {
      const btn = interaction as ButtonInteraction;
      const [ns, action, ...rest2] = btn.customId.split(":");
      try {
        if (ns === "bj") {
          await handleBjButton(btn, action!, rest2.join(":"));
          return;
        }
        if (ns === "phone") {
          await handlePhoneButton(btn, action!);
          return;
        }
        if (ns === "tw" && action === "like") {
          await handleSocialLike(btn, "tw", rest2[0]!);
          return;
        }
        if (ns === "ig" && action === "like") {
          await handleSocialLike(btn, "ig", rest2[0]!);
          return;
        }
        if (ns === "bm" && action === "buy") {
          await handleBmBuy(btn, rest2[0]!);
          return;
        }
      } catch (err) {
        logger.error({ err, customId: btn.customId }, "Button interaction error");
        const msg = { content: "Something went wrong.", ephemeral: true };
        if (btn.replied || btn.deferred) await btn.followUp(msg).catch(() => undefined);
        else await btn.reply(msg).catch(() => undefined);
      }
      return;
    }

    // ── Slash Commands ───────────────────────────────────────────────────────
    if (!interaction.isChatInputCommand()) return;
    const command = commandMap.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction as ChatInputCommandInteraction);
    } catch (err) {
      logger.error({ err, commandName: interaction.commandName }, "Command execution error");
      const msg = { content: "Something went wrong running that command.", ephemeral: true };
      if (interaction.replied || interaction.deferred) await interaction.followUp(msg).catch(() => undefined);
      else await interaction.reply(msg).catch(() => undefined);
    }
  });

  client.login(token).catch((err: unknown) => {
    logger.error({ err }, "Failed to login to Discord");
  });
}
